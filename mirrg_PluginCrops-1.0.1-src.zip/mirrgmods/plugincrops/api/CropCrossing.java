package mirrgmods.plugincrops.api;

import ic2.api.crops.CropCard;

import java.util.ArrayList;

public class CropCrossing
{

	/**
	 * from the last handler
	 */
	public static ArrayList<ICropCrossingHandler> handlers = new ArrayList<ICropCrossingHandler>();

	{
		handlers.add(new CropCrossingHandlerDefault());
	}

	public static int calculateRatioFor(CropCard a, CropCard b)
	{

		for (ICropCrossingHandler handler : handlers) {
			if (handler.isCalculating(a, b)) {
				return handler.calculateRatioFor(a, b);
			}
		}

		return 0;
	}

}
