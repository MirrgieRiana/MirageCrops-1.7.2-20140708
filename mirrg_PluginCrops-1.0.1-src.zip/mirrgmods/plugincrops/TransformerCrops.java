package mirrgmods.plugincrops;

import mirrgmods.plugincrops.api.CropCrossing;
import net.minecraft.launchwrapper.IClassTransformer;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class TransformerCrops implements IClassTransformer, Opcodes
{

	private static final String TARGET_CLASS_NAME = "ic2.core.block.TileEntityCrop";

	@Override
	public byte[] transform(String name, String paramString2, byte[] bytes)
	{

		if (!name.equals(TARGET_CLASS_NAME)) {
			return bytes;
		}

		System.out.println("transform(TileEntityCrop): begin");

		{
			ClassNode cnode = new ClassNode();
			ClassReader reader = new ClassReader(bytes);
			reader.accept(cnode, 0);

			String targetMethodName = "calculateRatioFor";
			String targetMethoddesc = "(Lic2/api/crops/CropCard;Lic2/api/crops/CropCard;)I";

			MethodNode mnode = null;
			for (MethodNode curMnode : cnode.methods) {
				if (targetMethodName.equals(curMnode.name) && targetMethoddesc.equals(curMnode.desc)) {
					mnode = curMnode;
					break;
				}
			}

			/*
			ListIterator<AbstractInsnNode> iterator = mnode.instructions.iterator();
			while (iterator.hasNext()) {
				AbstractInsnNode node = iterator.next();

				if (node instanceof VarInsnNode) {
					FMLLog.info("%s %d", "VarInsnNode", ((VarInsnNode) node).var);
				} else if (node instanceof JumpInsnNode) {
					FMLLog.info("%s %s", "JumpInsnNode", ((JumpInsnNode) node).label.getLabel());
				} else if (node instanceof LabelNode) {
					FMLLog.info("%s %s", "LabelNode", ((LabelNode) node).getLabel());
				} else if (node instanceof MethodInsnNode) {
					FMLLog.info("%s %s %s %s", "MethodInsnNode", ((MethodInsnNode) node).owner, ((MethodInsnNode) node).name, ((MethodInsnNode) node).desc);
				} else if (node instanceof InsnNode) {
					FMLLog.info("%s %d %d", "InsnNode", ((InsnNode) node).getOpcode(), ((InsnNode) node).getType());
				} else if (node instanceof IntInsnNode) {
					FMLLog.info("%s %d", "IntInsnNode", ((IntInsnNode) node).operand);
				} else {
					FMLLog.info("%s %d %d", node.toString(), node.getOpcode(), node.getType());
				}

			}
			*/

			if (mnode != null) {
				InsnList overrideList = new InsnList();

				overrideList.add(new VarInsnNode(ALOAD, 1));
				overrideList.add(new VarInsnNode(ALOAD, 2));

				overrideList.add(new MethodInsnNode(INVOKESTATIC,
					CropCrossing.class.getName().replaceAll("\\.", "/"),
					targetMethodName, targetMethoddesc));

				overrideList.add(new InsnNode(IRETURN));

				mnode.instructions.insert(mnode.instructions.get(1), overrideList);

				ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
				cnode.accept(cw);
				bytes = cw.toByteArray();

				System.out.println("transform(TileEntityCrop): end");
			} else {
				System.out.println("transform(TileEntityCrop): error: not found TileEntityCrop#" + targetMethodName + targetMethoddesc);
			}
		}

		return bytes;
	}

}
