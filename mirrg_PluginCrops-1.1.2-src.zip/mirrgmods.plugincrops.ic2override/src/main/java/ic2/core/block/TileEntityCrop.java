package ic2.core.block;

import ic2.api.crops.BaseSeed;
import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;
import ic2.api.network.INetworkDataProvider;
import ic2.api.network.INetworkUpdateListener;
import ic2.core.IC2;
import ic2.core.Ic2Items;
import ic2.core.block.crop.IC2Crops;
import ic2.core.block.invslot.InvSlotConsumable;
import ic2.core.item.ItemCropSeed;
import ic2.core.util.StackUtil;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import mirrgmods.plugincrops.api.CropCrossing;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class TileEntityCrop
	extends TileEntity
	implements INetworkDataProvider, INetworkUpdateListener, ICropTile
{
	public short id = -1;
	public byte size = 0;
	public byte statGrowth = 0;
	public byte statGain = 0;
	public byte statResistance = 0;
	public byte scanLevel = 0;
	public NBTTagCompound customData = new NBTTagCompound();
	public int nutrientStorage = 0;
	public int waterStorage = 0;
	public int exStorage = 0;
	public int growthPoints = 0;
	public boolean upgraded = false;

	@Override
	public void readFromNBT(NBTTagCompound nbttagcompound)
	{
		super.readFromNBT(nbttagcompound);
		this.id = nbttagcompound.getShort("cropid");
		this.size = nbttagcompound.getByte("size");
		this.statGrowth = nbttagcompound.getByte("statGrowth");
		this.statGain = nbttagcompound.getByte("statGain");
		this.statResistance = nbttagcompound.getByte("statResistance");
		if (nbttagcompound.hasKey("data0")) {
			for (int x = 0; x < 16; x++) {
				this.customData.setShort("legacy" + x, nbttagcompound.getShort("data" + x));
			}
		} else if (nbttagcompound.hasKey("customData")) {
			this.customData = nbttagcompound.getCompoundTag("customData");
		}
		this.growthPoints = nbttagcompound.getInteger("growthPoints");
		try
		{
			this.nutrientStorage = nbttagcompound.getInteger("nutrientStorage");
			this.waterStorage = nbttagcompound.getInteger("waterStorage");
		} catch (Throwable e)
		{
			this.nutrientStorage = nbttagcompound.getByte("nutrientStorage");
			this.waterStorage = nbttagcompound.getByte("waterStorage");
		}
		if (nbttagcompound.hasKey("exStorage", 3)) {
			this.exStorage = nbttagcompound.getByte("exStorage");
		} else {
			this.exStorage = 0;
		}
		this.upgraded = nbttagcompound.getBoolean("upgraded");
		this.scanLevel = nbttagcompound.getByte("scanLevel");

		crop();
	}

	@Override
	public void writeToNBT(NBTTagCompound nbttagcompound)
	{
		super.writeToNBT(nbttagcompound);
		nbttagcompound.setShort("cropid", this.id);
		nbttagcompound.setByte("size", this.size);
		nbttagcompound.setByte("statGrowth", this.statGrowth);
		nbttagcompound.setByte("statGain", this.statGain);
		nbttagcompound.setByte("statResistance", this.statResistance);
		nbttagcompound.setTag("customData", this.customData);
		nbttagcompound.setInteger("growthPoints", this.growthPoints);
		nbttagcompound.setInteger("nutrientStorage", this.nutrientStorage);
		nbttagcompound.setInteger("waterStorage", this.waterStorage);
		nbttagcompound.setInteger("exStorage", this.exStorage);
		nbttagcompound.setBoolean("upgraded", this.upgraded);
		nbttagcompound.setByte("scanLevel", this.scanLevel);
	}

	@Override
	public void updateEntity()
	{
		super.updateEntity();

		this.ticker = ((char) (this.ticker + '\001'));
		if (this.ticker % tickRate == 0) {
			tick();
		}
		if (this.dirty)
		{
			this.dirty = false;
			this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
			this.worldObj.updateLightByType(EnumSkyBlock.Block, this.xCoord, this.yCoord, this.zCoord);
			if (IC2.platform.isSimulating()) {
				if (!IC2.platform.isRendering()) {
					for (String field : getNetworkedFields()) {
						IC2.network.get().updateTileEntityField(this, field);
					}
				}
			}
		}
	}

	public char ticker = (char) IC2.random.nextInt(tickRate);
	public boolean dirty = true;
	public static char tickRate = 'Ā';

	@Override
	public List<String> getNetworkedFields()
	{
		List<String> ret = new ArrayList(4);

		ret.add("id");
		ret.add("size");
		ret.add("upgraded");
		ret.add("customData");

		return ret;
	}

	public void tick()
	{
		if (!IC2.platform.isSimulating()) {
			return;
		}
		if (this.ticker % (tickRate << '\002') == 0) {
			this.humidity = updateHumidity();
		}
		if ((this.ticker + tickRate) % (tickRate << '\002') == 0) {
			this.nutrients = updateNutrients();
		}
		if ((this.ticker + tickRate * '\002') % (tickRate << '\002') == 0) {
			this.airQuality = updateAirQuality();
		}
		if ((this.id < 0) && (
			(!this.upgraded) || (!attemptCrossing()))) {
			if ((IC2.random.nextInt(100) == 0) && (!hasEx()))
			{
				reset();
				this.id = ((short) IC2Crops.weed.getId());
				this.size = 1;
			}
			else
			{
				if ((this.exStorage > 0) && (IC2.random.nextInt(10) == 0)) {
					this.exStorage -= 1;
				}
				return;
			}
		}
		crop().tick(this);
		if (this.id < 0) return;
		if (crop().canGrow(this))
		{
			this.growthPoints += calcGrowthRate();
			if ((this.id > -1) && (this.growthPoints >= crop().growthDuration(this)))
			{
				this.growthPoints = 0;
				this.size = ((byte) (this.size + 1));
				this.dirty = true;
			}
		}
		if (this.nutrientStorage > 0) {
			this.nutrientStorage -= 1;
		}
		if (this.waterStorage > 0) {
			this.waterStorage -= 1;
		}
		if ((this.id > -1) && (crop().isWeed(this)) && (IC2.random.nextInt(50) - this.statGrowth <= 2)) {
			generateWeed();
		}
	}

	public void generateWeed()
	{
		int x = this.xCoord;
		int y = this.yCoord;
		int z = this.zCoord;
		switch (IC2.random.nextInt(4))
		{
			case 0:
				x++;
				break;
			case 1:
				x--;
				break;
			case 2:
				z++;
				break;
			case 3:
				z--;
				break;
		}
		if ((this.worldObj.getTileEntity(x, y, z) instanceof TileEntityCrop))
		{
			TileEntityCrop crop = (TileEntityCrop) this.worldObj.getTileEntity(x, y, z);
			if ((crop.id == -1) || ((!crop.crop().isWeed(crop)) && (IC2.random.nextInt(32) >= crop.statResistance)))
			{
				if (!crop.hasEx()) {
					byte newGrowth = this.statGrowth;
					if (crop.statGrowth > newGrowth) {
						newGrowth = crop.statGrowth;
					}
					if ((newGrowth < 31) && (IC2.random.nextBoolean())) {
						newGrowth = (byte) (newGrowth + 1);
					}
					crop.reset();
					crop.id = 0;
					crop.size = 1;
					crop.statGrowth = newGrowth;
				}
			}
		}
		else if (this.worldObj.isAirBlock(x, y, z))
		{
			Block block = this.worldObj.getBlock(x, y - 1, z);
			if ((block == Blocks.dirt) || (block == Blocks.grass) || (block == Blocks.farmland))
			{
				this.worldObj.setBlock(x, y - 1, z, Blocks.grass, 0, 7);

				this.worldObj.setBlock(x, y, z, Blocks.tallgrass, 1, 7);
			}
		}
	}

	public boolean hasEx()
	{
		if (this.exStorage > 0)
		{
			this.exStorage -= 5;
			return true;
		}
		return false;
	}

	public boolean attemptCrossing()
	{
		if (IC2.random.nextInt(3) != 0) {
			return false;
		}
		LinkedList<TileEntityCrop> crops = new LinkedList();
		askCropJoinCross(this.xCoord - 1, this.yCoord, this.zCoord, crops);
		askCropJoinCross(this.xCoord + 1, this.yCoord, this.zCoord, crops);
		askCropJoinCross(this.xCoord, this.yCoord, this.zCoord - 1, crops);
		askCropJoinCross(this.xCoord, this.yCoord, this.zCoord + 1, crops);
		if (crops.size() < 2) {
			return false;
		}
		int[] ratios = new int[256];
		for (int i = 1; i < ratios.length; i++)
		{
			CropCard crop = Crops.instance.getCropList()[i];
			if ((crop != null) && (crop.canGrow(this))) {
				for (int j = 0; j < crops.size(); j++) {
					ratios[i] += calculateRatioFor(crop, crops.get(j).crop());
				}
			}
		}
		int total = 0;
		for (int i = 0; i < ratios.length; i++) {
			total += ratios[i];
		}
		total = IC2.random.nextInt(total);
		for (int i = 0; i < ratios.length; i++)
		{
			if ((ratios[i] > 0) && (ratios[i] > total))
			{
				total = i;
				break;
			}
			total -= ratios[i];
		}
		this.upgraded = false;
		this.id = ((short) total);
		this.dirty = true;
		this.size = 1;

		this.statGrowth = 0;
		this.statResistance = 0;
		this.statGain = 0;
		for (int i = 0; i < crops.size(); i++)
		{
			this.statGrowth = ((byte) (this.statGrowth + crops.get(i).statGrowth));
			this.statResistance = ((byte) (this.statResistance + crops.get(i).statResistance));
			this.statGain = ((byte) (this.statGain + crops.get(i).statGain));
		}
		int count = crops.size();
		this.statGrowth = ((byte) (this.statGrowth / count));
		this.statResistance = ((byte) (this.statResistance / count));
		this.statGain = ((byte) (this.statGain / count));
		this.statGrowth = ((byte) (this.statGrowth + (IC2.random.nextInt(1 + 2 * count) - count)));
		if (this.statGrowth < 0) {
			this.statGrowth = 0;
		}
		if (this.statGrowth > 31) {
			this.statGrowth = 31;
		}
		this.statGain = ((byte) (this.statGain + (IC2.random.nextInt(1 + 2 * count) - count)));
		if (this.statGain < 0) {
			this.statGain = 0;
		}
		if (this.statGain > 31) {
			this.statGain = 31;
		}
		this.statResistance = ((byte) (this.statResistance + (IC2.random.nextInt(1 + 2 * count) - count)));
		if (this.statResistance < 0) {
			this.statResistance = 0;
		}
		if (this.statResistance > 31) {
			this.statResistance = 31;
		}
		return true;
	}

	public int calculateRatioFor(CropCard a, CropCard b)
	{
		return CropCrossing.calculateRatioFor(a, b);
		/*
		if (a == b) {
			return 500;
		}
		int value = 0;
		for (int i = 0; i < 5; i++)
		{
			int c = a.stat(i) - b.stat(i);
			if (c < 0) {
				c *= -1;
			}
			switch (c)
			{
				default:
					value--;
				case 0:
					value += 2;
				case 1:
					value++;
			}
		}
		for (int i = 0; i < a.attributes().length; i++) {
			for (int j = 0; j < b.attributes().length; j++) {
				if (a.attributes()[i].equalsIgnoreCase(b.attributes()[j])) {
					value += 5;
				}
			}
		}
		if (b.tier() < a.tier() - 1) {
			value -= 2 * (a.tier() - b.tier());
		}
		if (b.tier() - 3 > a.tier()) {
			value -= b.tier() - a.tier();
		}
		if (value < 0) {
			value = 0;
		}
		return value;
		*/
	}

	public void askCropJoinCross(int x, int y, int z, LinkedList<TileEntityCrop> crops)
	{
		if (!(this.worldObj.getTileEntity(x, y, z) instanceof TileEntityCrop)) {
			return;
		}
		TileEntityCrop sidecrop = (TileEntityCrop) this.worldObj.getTileEntity(x, y, z);
		if (sidecrop.id <= 0) {
			return;
		}
		if ((!sidecrop.crop().canGrow(this)) || (!sidecrop.crop().canCross(sidecrop))) {
			return;
		}
		int base = 4;
		if (sidecrop.statGrowth >= 16) {
			base++;
		}
		if (sidecrop.statGrowth >= 30) {
			base++;
		}
		if (sidecrop.statResistance >= 28) {
			base += 27 - sidecrop.statResistance;
		}
		if (base >= IC2.random.nextInt(20)) {
			crops.add(sidecrop);
		}
	}

	public boolean leftclick(EntityPlayer player)
	{
		if (this.id < 0)
		{
			if (this.upgraded)
			{
				this.upgraded = false;
				this.dirty = true;
				if (IC2.platform.isSimulating()) {
					StackUtil.dropAsEntity(this.worldObj, this.xCoord, this.yCoord, this.zCoord, new ItemStack(Ic2Items.crop.getItem()));
				}
				return true;
			}
			return false;
		}
		return crop().leftclick(this, player);
	}

	@Override
	public boolean pick(boolean manual)
	{
		if (this.id < 0) {
			return false;
		}
		byte sizeTmp = this.size;
		boolean bonus = harvest(false);
		this.size = sizeTmp;
		float firstchance = crop().dropSeedChance(this);
		for (int i = 0; i < this.statResistance; i++) {
			firstchance *= 1.1F;
		}
		int drop = 0;
		if (bonus)
		{
			if (IC2.random.nextFloat() <= (firstchance + 1.0F) * 0.8F) {
				drop++;
			}
			float chance = crop().dropSeedChance(this) + this.statGrowth / 100.0F;
			if (!manual) {
				chance *= 0.8F;
			}
			for (int i = 23; i < this.statGain; i++) {
				chance *= 0.95F;
			}
			if (IC2.random.nextFloat() <= chance) {
				drop++;
			}
		}
		else if (IC2.random.nextFloat() <= firstchance * 1.5F)
		{
			drop++;
		}
		ItemStack[] re = new ItemStack[drop];
		for (int i = 0; i < drop; i++) {
			re[i] = crop().getSeeds(this);
		}
		reset();
		if ((IC2.platform.isSimulating()) && (re.length > 0)) {
			for (int x = 0; x < re.length; x++)
			{
				if (re[x].getItem() != Ic2Items.cropSeed.getItem()) {
					re[x].stackTagCompound = null;
				}
				StackUtil.dropAsEntity(this.worldObj, this.xCoord, this.yCoord, this.zCoord, re[x]);
			}
		}
		return true;
	}

	public boolean rightclick(EntityPlayer player)
	{
		ItemStack current = player.getCurrentEquippedItem();
		if (current != null)
		{
			if (this.id < 0)
			{
				if ((current.getItem() == Ic2Items.crop.getItem()) && (!this.upgraded))
				{
					if (!player.capabilities.isCreativeMode)
					{
						current.stackSize -= 1;
						if (current.stackSize <= 0) {
							player.inventory.mainInventory[player.inventory.currentItem] = null;
						}
					}
					this.upgraded = true;
					this.dirty = true;
					return true;
				}
				if (applyBaseSeed(player)) {
					return true;
				}
			}
			else if (current.getItem() == Ic2Items.cropnalyzer.getItem())
			{
				if (IC2.platform.isSimulating())
				{
					String desc = getScanned();
					if (desc == null) {
						desc = "Unknown Crop";
					}
					IC2.platform.messagePlayer(player, desc, new Object[0]);
				}
				return true;
			}
			if ((current.getItem() == Items.water_bucket) || (current.getItem() == Ic2Items.waterCell.getItem()))
			{
				if (this.waterStorage < 10)
				{
					this.waterStorage = 10;
					return true;
				}
				return current.getItem() == Items.water_bucket;
			}
			if (current.getItem() == Items.wheat_seeds)
			{
				if (this.nutrientStorage <= 50)
				{
					this.nutrientStorage += 25;
					current.stackSize -= 1;
					if (current.stackSize <= 0) {
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					}
					return true;
				}
				return false;
			}
			if (((current.getItem() == Items.dye) && (current.getItemDamage() == 15)) || (current.getItem() == Ic2Items.fertilizer.getItem()))
			{
				if (applyFertilizer(true))
				{
					current.stackSize -= 1;
					if (current.stackSize <= 0) {
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					}
					return true;
				}
				return false;
			}
			if (current.getItem() == Ic2Items.hydratingCell.getItem())
			{
				if (applyHydration(true, current))
				{
					if (current.stackSize <= 0) {
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					}
					return true;
				}
				return false;
			}
			if ((current.getItem() == Ic2Items.weedEx.getItem()) &&
				(applyWeedEx(true)))
			{
				current.damageItem(1, player);
				if (current.stackSize <= 0) {
					player.inventory.mainInventory[player.inventory.currentItem] = null;
				}
				return true;
			}
		}
		if (this.id < 0) {
			return false;
		}
		return crop().rightclick(this, player);
	}

	public boolean applyBaseSeed(EntityPlayer player)
	{
		ItemStack current = player.getCurrentEquippedItem();
		BaseSeed seed = Crops.instance.getBaseSeed(current);
		if (seed != null)
		{
			if (current.stackSize < seed.stackSize) {
				return false;
			}
			if (tryPlantIn(seed.id, seed.size, seed.statGrowth, seed.statGain, seed.statResistance, 1))
			{
				if (current.getItem().hasContainerItem(current))
				{
					if (current.stackSize > 1) {
						return false;
					}
					player.inventory.mainInventory[player.inventory.currentItem] = current.getItem().getContainerItem(current);
				}
				else
				{
					current.stackSize -= seed.stackSize;
					if (current.stackSize <= 0) {
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					}
				}
				return true;
			}
		}
		return false;
	}

	public boolean tryPlantIn(int i, int si, int statGr, int statGa, int statRe, int scan)
	{
		if ((this.id > -1) || (i <= 0) || (this.upgraded)) {
			return false;
		}
		if (!Crops.instance.getCropList()[i].canGrow(this)) {
			return false;
		}
		reset();
		this.id = ((short) i);
		this.size = ((byte) si);
		this.statGrowth = ((byte) statGr);
		this.statGain = ((byte) statGa);
		this.statResistance = ((byte) statRe);
		this.scanLevel = ((byte) scan);
		return true;
	}

	public boolean applyFertilizer(boolean manual)
	{
		if (this.nutrientStorage >= 100) {
			return false;
		}
		this.nutrientStorage += (manual ? 100 : 90);
		return true;
	}

	public boolean applyHydration(boolean manual, InvSlotConsumable hydrationSlot)
	{
		if (((!manual) && (this.waterStorage >= 180)) || (this.waterStorage >= 200)) {
			return false;
		}
		int apply = manual ? 200 - this.waterStorage : 180 - this.waterStorage;
		ItemStack affected = hydrationSlot.damage(apply, null);

		apply = affected.stackSize * affected.getMaxDamage() + affected.getItemDamage();

		this.waterStorage += apply;

		return true;
	}

	public boolean applyHydration(boolean manual, ItemStack itemStack)
	{
		if (((!manual) && (this.waterStorage >= 180)) || (this.waterStorage >= 200)) {
			return false;
		}
		int apply = manual ? 200 - this.waterStorage : 180 - this.waterStorage;

		apply = Math.min(apply, itemStack.getMaxDamage() - itemStack.getItemDamage());
		if (itemStack.attemptDamageItem(apply, new Random()))
		{
			itemStack.stackSize -= 1;
			itemStack.setItemDamage(0);
		}
		this.waterStorage += apply;

		return true;
	}

	@SuppressWarnings("fallthrough")
	public boolean applyWeedEx(boolean manual)
	{
		if (((this.exStorage >= 100) && (manual)) || (this.exStorage >= 150)) {
			return false;
		}
		this.exStorage += 50;
		boolean trigger = this.worldObj.rand.nextInt(3) == 0;
		if (manual) {
			trigger = this.worldObj.rand.nextInt(5) == 0;
		}
		if ((this.id > 0) && (this.exStorage >= 75) && (trigger))
		{
			switch (this.worldObj.rand.nextInt(5))
			{
				case 0:
					if (this.statGrowth > 0) {
						this.statGrowth = ((byte) (this.statGrowth - 1));
					}
				case 1:
					if (this.statGain > 0) {
						this.statGain = ((byte) (this.statGain - 1));
					}
					break;
			}
			if (this.statResistance > 0) {
				this.statResistance = ((byte) (this.statResistance - 1));
			}
		}
		return true;
	}

	@Override
	public boolean harvest(boolean manual)
	{
		if ((this.id < 0) || (!crop().canBeHarvested(this))) {
			return false;
		}
		float chance = crop().dropGainChance();
		for (int i = 0; i < this.statGain; i++) {
			chance *= 1.03F;
		}
		chance -= IC2.random.nextFloat();
		int drop = 0;
		while (chance > 0.0F)
		{
			drop++;
			chance -= IC2.random.nextFloat();
		}
		ItemStack[] re = new ItemStack[drop];
		for (int i = 0; i < drop; i++)
		{
			re[i] = crop().getGain(this);
			if ((re[i] != null) && (IC2.random.nextInt(100) <= this.statGain)) {
				re[i].stackSize += 1;
			}
		}
		this.size = crop().getSizeAfterHarvest(this);
		this.dirty = true;
		if ((IC2.platform.isSimulating()) && (re.length > 0)) {
			for (int x = 0; x < re.length; x++) {
				StackUtil.dropAsEntity(this.worldObj, this.xCoord, this.yCoord, this.zCoord, re[x]);
			}
		}
		return true;
	}

	public void onNeighbourChange()
	{
		if (this.id < 0) {
			return;
		}
		crop().onNeighbourChange(this);
	}

	public int emitRedstone()
	{
		if (this.id < 0) {
			return 0;
		}
		return crop().emitRedstone(this);
	}

	public void onBlockDestroyed()
	{
		if (this.id < 0) {
			return;
		}
		crop().onBlockDestroyed(this);
	}

	public int getEmittedLight()
	{
		if (this.id < 0) {
			return 0;
		}
		return crop().getEmittedLight(this);
	}

	@Override
	public byte getHumidity()
	{
		if (this.humidity == -1) {
			this.humidity = updateHumidity();
		}
		return this.humidity;
	}

	public byte humidity = -1;

	@Override
	public byte getNutrients()
	{
		if (this.nutrients == -1) {
			this.nutrients = updateNutrients();
		}
		return this.nutrients;
	}

	public byte nutrients = -1;

	@Override
	public byte getAirQuality()
	{
		if (this.airQuality == -1) {
			this.airQuality = updateAirQuality();
		}
		return this.airQuality;
	}

	public byte airQuality = -1;

	public byte updateHumidity()
	{
		int value = Crops.instance.getHumidityBiomeBonus(this.worldObj.getBiomeGenForCoords(this.xCoord, this.zCoord));
		if (this.worldObj.getBlockMetadata(this.xCoord, this.yCoord - 1, this.zCoord) >= 7) {
			value += 2;
		}
		if (this.waterStorage >= 5) {
			value += 2;
		}
		value += (this.waterStorage + 24) / 25;
		return (byte) value;
	}

	public byte updateNutrients()
	{
		int value = Crops.instance.getNutrientBiomeBonus(this.worldObj.getBiomeGenForCoords(this.xCoord, this.zCoord));
		for (int i = 2; i < 5; i++)
		{
			if (this.worldObj.getBlock(this.xCoord, this.yCoord - i, this.zCoord) != Blocks.dirt) {
				break;
			}
			value++;
		}
		value += (this.nutrientStorage + 19) / 20;
		return (byte) value;
	}

	public byte updateAirQuality()
	{
		int value = 0;
		int height = (this.yCoord - 64) / 15;
		if (height > 4) {
			height = 4;
		}
		if (height < 0) {
			height = 0;
		}
		value += height;
		int fresh = 9;
		for (int x = this.xCoord - 1; (x <= this.xCoord + 1) && (fresh > 0); x++) {
			for (int z = this.zCoord - 1; (z <= this.zCoord + 1) && (fresh > 0); z++) {
				if ((this.worldObj.isBlockNormalCubeDefault(x, this.yCoord, z, false)) || ((this.worldObj.getTileEntity(x, this.yCoord, z) instanceof TileEntityCrop))) {
					fresh--;
				}
			}
		}
		value += fresh / 2;
		if (this.worldObj.canBlockSeeTheSky(this.xCoord, this.yCoord + 1, this.zCoord)) {
			value += 2;
		}
		return (byte) value;
	}

	public byte updateMultiCulture()
	{
		LinkedList<CropCard> crops = new LinkedList();
		for (int x = -1; x < 1; x++) {
			for (int z = -1; z < 1; z++) {
				if ((this.worldObj.getTileEntity(x + this.xCoord, this.yCoord, z + this.zCoord) instanceof TileEntityCrop)) {
					addIfNotPresent(((TileEntityCrop) this.worldObj.getTileEntity(x + this.xCoord, this.yCoord, z + this.zCoord)).crop(), crops);
				}
			}
		}
		return (byte) (crops.size() - 1);
	}

	public void addIfNotPresent(CropCard crop, LinkedList<CropCard> crops)
	{
		for (int i = 0; i < crops.size(); i++) {
			if (crop == crops.get(i)) {
				return;
			}
		}
		crops.add(crop);
	}

	public int calcGrowthRate()
	{
		int base = 3 + IC2.random.nextInt(7) + this.statGrowth;
		int need = (crop().tier() - 1) * 4 + this.statGrowth + this.statGain + this.statResistance;
		if (need < 0) {
			need = 0;
		}
		int have = crop().weightInfluences(this, getHumidity(), getNutrients(), getAirQuality()) * 5;
		if (have >= need)
		{
			base = base * (100 + (have - need)) / 100;
		}
		else
		{
			int neg = (need - have) * 4;
			if ((neg > 100) && (IC2.random.nextInt(32) > this.statResistance))
			{
				reset();
				base = 0;
			}
			else
			{
				base = base * (100 - neg) / 100;
				if (base < 0) {
					base = 0;
				}
			}
		}
		return base;
	}

	public void calcTrampling()
	{
		if (!IC2.platform.isSimulating()) {
			return;
		}
		if ((IC2.random.nextInt(100) == 0) && (IC2.random.nextInt(40) > this.statResistance))
		{
			reset();
			this.worldObj.setBlock(this.xCoord, this.yCoord - 1, this.zCoord, Blocks.dirt, 0, 7);
		}
	}

	public CropCard crop()
	{
		if (this.id < 0) return null;
		if (this.id >= Crops.instance.getCropList().length) return null;

		CropCard cropCard = Crops.instance.getCropList()[this.id];
		if (cropCard == null) {
			this.id = 0;
			this.size = 1;
			cropCard = Crops.instance.getCropList()[this.id];
		}

		if (size < 1) size = 1;
		if (size > cropCard.maxSize()) size = (byte) cropCard.maxSize();

		return cropCard;
	}

	public void onEntityCollision(Entity entity)
	{
		if (this.id < 0) {
			return;
		}
		if (crop().onEntityCollision(this, entity)) {
			calcTrampling();
		}
	}

	@Override
	public void reset()
	{
		this.id = -1;
		this.size = 0;
		this.customData = new NBTTagCompound();
		this.dirty = true;
		this.statGain = 0;
		this.statResistance = 0;
		this.statGrowth = 0;
		this.nutrients = -1;
		this.airQuality = -1;
		this.humidity = -1;
		this.growthPoints = 0;
		this.upgraded = false;
		this.scanLevel = 0;
	}

	@Override
	public void updateState()
	{
		this.dirty = true;
	}

	public String getScanned()
	{
		if ((this.scanLevel <= 0) || (this.id < 0)) {
			return null;
		}
		if (this.scanLevel >= 4) {
			return crop().name() + " - Gr: " + this.statGrowth + " Ga: " + this.statGain + " Re: " + this.statResistance;
		}
		return crop().name();
	}

	@Override
	public boolean isBlockBelow(Block reqBlock)
	{
		for (int i = 2; i <= 4; i++)
		{
			Block block = this.worldObj.getBlock(this.xCoord, this.yCoord - i, this.zCoord);
			if (block.isAir(this.worldObj, this.xCoord, this.yCoord - i, this.zCoord)) {
				return false;
			}
			if (block == reqBlock) {
				return true;
			}
		}
		return false;
	}

	@Override
	public ItemStack generateSeeds(short plant, byte growth, byte gain, byte resis, byte scan)
	{
		return ItemCropSeed.generateItemStackFromValues(plant, growth, gain, resis, scan);
	}

	@Override
	public void onNetworkUpdate(String field)
	{
		this.dirty = true;
	}

	@Override
	public short getID()
	{
		return this.id;
	}

	@Override
	public byte getSize()
	{
		return this.size;
	}

	@Override
	public byte getGrowth()
	{
		return this.statGrowth;
	}

	@Override
	public byte getGain()
	{
		return this.statGain;
	}

	@Override
	public byte getResistance()
	{
		return this.statResistance;
	}

	@Override
	public byte getScanLevel()
	{
		return this.scanLevel;
	}

	@Override
	public NBTTagCompound getCustomData()
	{
		return this.customData;
	}

	@Override
	public int getNutrientStorage()
	{
		return this.nutrientStorage;
	}

	@Override
	public int getHydrationStorage()
	{
		return this.waterStorage;
	}

	@Override
	public int getWeedExStorage()
	{
		return this.exStorage;
	}

	@Override
	public int getLightLevel()
	{
		return this.worldObj.getBlockLightValue(this.xCoord, this.yCoord, this.zCoord);
	}

	@Override
	public void setID(short id1)
	{
		this.id = id1;
		this.dirty = true;
	}

	@Override
	public void setSize(byte size1)
	{
		this.size = size1;
		this.dirty = true;
	}

	@Override
	public void setGrowth(byte growth)
	{
		this.statGrowth = growth;
	}

	@Override
	public void setGain(byte gain)
	{
		this.statGain = gain;
	}

	@Override
	public void setResistance(byte resistance)
	{
		this.statResistance = resistance;
	}

	@Override
	public void setScanLevel(byte scanLevel1)
	{
		this.scanLevel = scanLevel1;
	}

	@Override
	public void setNutrientStorage(int nutrientStorage1)
	{
		this.nutrientStorage = nutrientStorage1;
	}

	@Override
	public void setHydrationStorage(int hydrationStorage)
	{
		this.waterStorage = hydrationStorage;
	}

	@Override
	public void setWeedExStorage(int weedExStorage)
	{
		this.exStorage = weedExStorage;
	}

	@Override
	public World getWorld()
	{
		return this.worldObj;
	}

	@Override
	public ChunkCoordinates getLocation()
	{
		return new ChunkCoordinates(this.xCoord, this.yCoord, this.zCoord);
	}
}
