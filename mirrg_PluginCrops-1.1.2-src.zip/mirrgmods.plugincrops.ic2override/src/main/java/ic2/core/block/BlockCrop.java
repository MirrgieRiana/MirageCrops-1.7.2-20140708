package ic2.core.block;

import ic2.api.crops.Crops;
import ic2.core.IC2;
import ic2.core.init.InternalName;
import ic2.core.item.block.ItemBlockIC2;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IIcon;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class BlockCrop
	extends BlockMultiID
{
	public static TileEntityCrop tempStore;
	private static final int textureIndexStick = 0;
	private static final int textureIndexStickUpgraded = 1;

	public BlockCrop(InternalName internalName1)
	{
		super(internalName1, Material.plants, ItemBlockIC2.class);

		setHardness(0.8F);
		setResistance(0.2F);
		setStepSound(soundTypeGrass);

		ic2.core.Ic2Items.crop = new ItemStack(this, 1, 0);
	}

	public String getTextureFolder(int id)
	{
		return "crop";
	}

	public int getTextureIndex(int meta)
	{
		if ((meta == 0) || (meta == 1)) {
			return meta;
		}
		return 0;
	}

	public String getTextureName(int index)
	{
		switch (index)
		{
			case 0:
				return getUnlocalizedName() + "." + InternalName.stick.name();
			case 1:
				return getUnlocalizedName() + "." + InternalName.stick.name() + "." + InternalName.upgraded.name();
		}
		return null;
	}

	@SideOnly(Side.CLIENT)
	public void registerBlockIcons(IIconRegister iconRegister)
	{
		super.registerBlockIcons(iconRegister);

		Crops.instance.startSpriteRegistration(iconRegister);
	}

	public TileEntity createTileEntity(World world, int metaData)
	{
		return new TileEntityCrop();
	}

	@SideOnly(Side.CLIENT)
	public IIcon getIcon(IBlockAccess iBlockAccess, int x, int y, int z, int side)
	{
		TileEntity te = iBlockAccess.getTileEntity(x, y, z);
		if ((te instanceof TileEntityCrop))
		{
			TileEntityCrop tileEntityCrop = (TileEntityCrop) te;
			if (tileEntityCrop.id < 0)
			{
				if (!tileEntityCrop.upgraded) {
					return getIcon(side, 0);
				}
				return getIcon(side, 1);
			}
			return tileEntityCrop.crop().getSprite(tileEntityCrop);
		}
		return super.getIcon(iBlockAccess, x, y, z, side);
	}

	public boolean canPlaceBlockAt(World world, int x, int y, int z)
	{
		return (world.getBlock(x, y - 1, z) == Blocks.farmland) && (super.canPlaceBlockAt(world, x, y, z));
	}

	public void onNeighborBlockChange(World world, int x, int y, int z, Block neighbor)
	{
		super.onNeighborBlockChange(world, x, y, z, neighbor);
		if (world.getBlock(x, y - 1, z) != Blocks.farmland)
		{
			world.setBlockToAir(x, y, z);
			dropBlockAsItem(world, x, y, z, 0, 0);
		}
		else
		{
			((TileEntityCrop) world.getTileEntity(x, y, z)).onNeighbourChange();
		}
	}

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
	{
		double d = 0.2D;
		return AxisAlignedBB.getBoundingBox(d, 0.0D, d, 1.0D - d, 0.7D, 1.0D - d);
	}

	public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
	{
		TileEntity tileEntity = world.getTileEntity(i, j, k);
		if (tileEntity != null && tileEntity instanceof TileEntityCrop) {
			((TileEntityCrop) tileEntity).onEntityCollision(entity);
		}
	}

	public boolean isOpaqueCube()
	{
		return false;
	}

	public boolean renderAsNormalBlock()
	{
		return false;
	}

	public int getRenderType()
	{
		return IC2.platform.getRenderId("crop");
	}

	public int isProvidingWeakPower(IBlockAccess iblockaccess, int i, int j, int k, int l)
	{
		return ((TileEntityCrop) iblockaccess.getTileEntity(i, j, k)).emitRedstone();
	}

	public void breakBlock(World world, int x, int y, int z, Block block, int meta)
	{
		tempStore = (TileEntityCrop) world.getTileEntity(x, y, z);

		super.breakBlock(world, x, y, z, block, meta);
	}

	public void onBlockDestroyedByExplosion(World world, int x, int y, int z, Explosion explosion)
	{
		if (tempStore != null) {
			tempStore.onBlockDestroyed();
		}
	}

	public int getLightValue(IBlockAccess iblockaccess, int i, int j, int k)
	{
		return ((TileEntityCrop) iblockaccess.getTileEntity(i, j, k)).getEmittedLight();
	}

	public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
	{
		if (!world.isRemote) {
			((TileEntityCrop) world.getTileEntity(i, j, k)).leftclick(entityplayer);
		}
	}

	public boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, int side, float a, float b, float c)
	{
		if (world.isRemote) {
			return true;
		}
		return ((TileEntityCrop) world.getTileEntity(i, j, k)).rightclick(entityplayer);
	}
}
