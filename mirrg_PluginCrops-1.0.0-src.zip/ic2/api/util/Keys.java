package ic2.api.util;

public class Keys
{
	public static IKeyboard instance;
}
