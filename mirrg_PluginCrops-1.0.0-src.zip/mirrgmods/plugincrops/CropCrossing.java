package mirrgmods.plugincrops;

import ic2.api.crops.CropCard;
import mirrgmods.plugincrops.api.CropCrossingHandler;
import mirrgmods.plugincrops.api.CropCrossingHandler.ICropCrossingHandler;

public class CropCrossing
{

	public static ICropCrossingHandler defaultHandler = new CropCrossingHandlerDefault();

	public static int calculateRatioFor(CropCard a, CropCard b)
	{

		for (ICropCrossingHandler handler : CropCrossingHandler.handlers) {
			if (handler.isCalculating(a, b)) {
				return handler.calculateRatioFor(a, b);
			}
		}

		return defaultHandler.calculateRatioFor(a, b);
	}

}
