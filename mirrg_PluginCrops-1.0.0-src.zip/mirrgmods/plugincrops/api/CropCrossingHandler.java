package mirrgmods.plugincrops.api;

import ic2.api.crops.CropCard;

import java.util.ArrayList;

public class CropCrossingHandler
{

	public static ArrayList<ICropCrossingHandler> handlers = new ArrayList<ICropCrossingHandler>();

	public interface ICropCrossingHandler
	{

		public boolean isCalculating(CropCard a, CropCard b);

		public int calculateRatioFor(CropCard a, CropCard b);

	}

}
