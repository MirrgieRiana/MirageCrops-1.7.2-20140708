package mirrgmods.plugincrops;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import mirrgmods.plugincrops.deobf.HelperSrg;
import mirrgmods.plugincrops.framework.ClassEntry;
import mirrgmods.plugincrops.framework.HelperDeobf;
import mirrgmods.plugincrops.framework.HelperDeobf.HelperException;
import mirrgmods.plugincrops.transform.TransformEntryClass;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin;

public class PluginCrops implements IFMLLoadingPlugin
{

	public static PluginCrops instance = null;
	public static String VERSION = "1.1.1";

	public PluginCrops()
	{
		synchronized (PluginCrops.class) {
			if (instance != null && instance != this) return;
			instance = this;
		}

		//

		FMLLog.info("[PluginCrops] HelperDeobf.isDeobfuscated: " + HelperDeobf.isDeobfuscated());

		TransformerCrops.entries.clear();

		TransformerCrops.entries.add(new TransformEntryClass(new ClassEntry("ic2.core.block.TileEntityCrop".replaceAll("\\.", "/"))) {
			@Override
			public byte[] onTransform(ClassEntry classEntry, byte[] bytes)
			{
				String classAbsolutePath = "/" + PluginCrops.class.getName().replaceAll("\\.", "/") + ".class";
				String path = HelperSrg.getResource(classAbsolutePath).toString().replace(classAbsolutePath, "") + "/" + classEntry.name + ".class.bin";

				try {
					URL url = new URL(path);
					return HelperDeobf.getBytes(url);
				} catch (HelperException e) {
					throw new RuntimeException(e);
				} catch (MalformedURLException e) {
					throw new RuntimeException(e);
				}

			}
		});

	}

	@Override
	public String[] getASMTransformerClass()
	{
		return instance == this ? new String[] {
			TransformerCrops.class.getName(),
		} : null;
	}

	@Override
	public String getModContainerClass()
	{
		return ModContainerCrops.class.getName();
	}

	@Override
	public String getSetupClass()
	{
		return null;
	}

	@Override
	public void injectData(Map<String, Object> data)
	{

	}

	@Override
	public String getAccessTransformerClass()
	{
		return null;
	}

}
