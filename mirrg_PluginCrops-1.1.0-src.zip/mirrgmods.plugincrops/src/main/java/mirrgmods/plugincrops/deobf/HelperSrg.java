package mirrgmods.plugincrops.deobf;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;

import com.google.common.io.CharStreams;

import cpw.mods.fml.common.asm.transformers.deobf.LZMAInputSupplier;

public class HelperSrg
{

	public enum EnumType
	{
		NON_COMPRESS, LZMA,
	}

	public static List<String> getLines(String srgName, EnumType type) throws IOException
	{
		return getLines(ClassLoader.getSystemClassLoader(), srgName, type);
	}

	public static List<String> getLines(ClassLoader classLoader, String srgName, EnumType type) throws IOException
	{
		return getLines(classLoader.getResource(srgName), type);
	}

	public static List<String> getLines(URL url, EnumType type) throws IOException
	{
		InputStream is = url.openStream();
		if (is == null) throw new FileNotFoundException(url.toString());
		List<String> lines = getLines(is, type);
		is.close();
		return lines;
	}

	public static List<String> getLines(InputStream inputStream, EnumType type) throws IOException
	{
		if (type == EnumType.LZMA) {
			LZMAInputSupplier lzma = new LZMAInputSupplier(inputStream);
			InputStream is = lzma.getInput();
			List<String> lines = getLines(is, EnumType.NON_COMPRESS);
			is.close();
			return lines;
		} else {
			return getLines(new InputStreamReader(inputStream));
		}
	}

	public static List<String> getLines(Readable readable) throws IOException
	{
		return CharStreams.readLines(readable);
	}

	public static URL getResource(String absolutePath)
	{
		String path = absolutePath.substring(1);

		URL url;

		url = ClassLoader.getSystemClassLoader().getResource(path);

		if (url == null) {
			url = HelperSrg.class.getClassLoader().getResource(path);
		}

		return url;
	}

}
