package mirrgmods.plugincrops.deobf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.objectweb.asm.commons.Remapper;

public class MirrgSrgRemapper extends Remapper
{

	public Map<String, String> classMap = new HashMap<String, String>();
	public Map<String, String> fieldMap = new HashMap<String, String>();
	public Map<String, String> methodMap = new HashMap<String, String>();

	public void load(List<String> lines, boolean inverse)
	{
		for (String line : lines)
		{
			if (line.startsWith("CL: ")) {
				parseClass(line.substring(4), inverse);
			} else if (line.startsWith("FD: ")) {
				parseField(line.substring(4), inverse);
			} else if (line.startsWith("MD: ")) {
				parseMethod(line.substring(4), inverse);
			}
		}
	}

	// net/minecraft/profiler/PlayerUsageSnooper net/minecraft/profiler/PlayerUsageSnooper
	protected void parseClass(String line, boolean inverse)
	{
		String[] split = line.split(" ");
		if (!inverse) {
			classMap.put(split[0], split[1]);
		} else {
			classMap.put(split[1], split[0]);
		}
	}

	// net/minecraft/village/Village/worldObj net/minecraft/village/Village/field_75586_a
	protected void parseField(String line, boolean inverse)
	{
		String[] split = line.split(" ");
		if (!inverse) {
			fieldMap.put(split[0], split[1].substring(split[1].lastIndexOf("/") + 1));
		} else {
			fieldMap.put(split[1], split[0].substring(split[0].lastIndexOf("/") + 1));
		}
	}

	// net/minecraft/entity/EntityLiving/setAlwaysRenderNameTag (Z)V net/minecraft/entity/EntityLiving/func_94061_f (Z)V
	protected void parseMethod(String line, boolean inverse)
	{
		String[] split = line.split(" ");
		if (!inverse) {
			methodMap.put(split[0] + split[1], split[2].substring(split[2].lastIndexOf("/") + 1));
		} else {
			methodMap.put(split[2] + split[3], split[0].substring(split[0].lastIndexOf("/") + 1));
		}
	}

	@Override
	public String map(String typeName)
	{
		if (classMap.containsKey(typeName)) {
			return classMap.get(typeName);
		}

		return typeName;
	}

	@Override
	public String mapFieldName(String owner, String name, String desc)
	{
		String key = owner + "/" + name;

		if (methodMap.containsKey(key)) {
			return methodMap.get(key);
		}

		return name;
	}

	@Override
	public String mapMethodName(String owner, String name, String desc)
	{
		String key = owner + "/" + name + desc;

		if (methodMap.containsKey(key)) {
			return methodMap.get(key);
		}

		return name;
	}

}
