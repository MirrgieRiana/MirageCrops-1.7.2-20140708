package mirrgmods.plugincrops.transform;

public class TransformEntry
{

	public byte[] onTransform(String name, String paramString2, byte[] bytes)
	{
		return bytes;
	}

}
