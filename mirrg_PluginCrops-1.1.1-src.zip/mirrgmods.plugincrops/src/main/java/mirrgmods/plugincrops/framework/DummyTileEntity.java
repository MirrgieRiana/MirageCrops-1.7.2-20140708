package mirrgmods.plugincrops.framework;

import net.minecraft.tileentity.TileEntity;

public class DummyTileEntity extends TileEntity
{

	@Override
	public void markDirty()
	{
		super.markDirty();
	}

}
