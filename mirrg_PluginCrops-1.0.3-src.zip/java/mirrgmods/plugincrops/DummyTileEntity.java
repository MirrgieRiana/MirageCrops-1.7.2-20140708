package mirrgmods.plugincrops;

import net.minecraft.tileentity.TileEntity;

public class DummyTileEntity extends TileEntity
{

	@Override
	public void markDirty()
	{
		super.markDirty();
	}

}
