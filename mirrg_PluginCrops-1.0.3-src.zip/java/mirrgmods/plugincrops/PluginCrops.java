package mirrgmods.plugincrops;

import java.util.Map;

import mirrgmods.plugincrops.api.CropCrossing;
import mirrgmods.plugincrops.deobf.Mappings;
import mirrgmods.plugincrops.transform.TransformEntryMethod;
import mirrgmods.plugincrops.transform.TransformEntryMethodRedirection;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin;

public class PluginCrops implements IFMLLoadingPlugin
{

	public static PluginCrops instance = null;
	public static String VERSION = "1.0.3";

	public PluginCrops()
	{
		synchronized (PluginCrops.class) {
			if (instance != null && instance != this) return;
			instance = this;
		}

		//

		FMLLog.info("[PluginCrops] HelperDeobf.isDeobfuscated: " + HelperDeobf.isDeobfuscated());

		TransformEntryMethod.debug = false;

		TransformerCrops.entries.clear();

		TransformerCrops.entries.add(new TransformEntryMethodRedirection(
			new MethodEntry("ic2.core.block.TileEntityCrop".replaceAll("\\.", "/"),
				"calculateRatioFor",
				"(Lic2/api/crops/CropCard;Lic2/api/crops/CropCard;)I"),
			new MethodEntry("ic2.core.block.TileEntityCrop".replaceAll("\\.", "/"),
				"calculateRatioFor",
				"(Lic2/api/crops/CropCard;Lic2/api/crops/CropCard;)I"),
			CropCrossing.class.getName().replaceAll("\\.", "/"),
			new int[] {
				Opcodes.ALOAD,
				Opcodes.ALOAD,
			},
			Opcodes.IRETURN));

		TransformerCrops.entries.add(new TransformEntryMethod(
			new MethodEntry("ic2.core.block.TileEntityCrop".replaceAll("\\.", "/"),
				"writeToNBT",
				"(Lnet/minecraft/nbt/NBTTagCompound;)V"),
			new MethodEntry("net.minecraft.tileentity.TileEntity".replaceAll("\\.", "/"),
				"writeToNBT",
				"(Lnet/minecraft/nbt/NBTTagCompound;)V")) {

			@Override
			public void onTransform(MethodNode mnode)
			{
				InsnList overrideList = new InsnList();

				overrideList.add(new VarInsnNode(Opcodes.ALOAD, 1));
				overrideList.add(new LdcInsnNode("exStorage"));
				overrideList.add(new VarInsnNode(Opcodes.ALOAD, 0));
				overrideList.add(new FieldInsnNode(Opcodes.GETFIELD, method.owner, "exStorage", "I"));

				{
					MethodEntry replacement = new MethodEntry(
						"net/minecraft/nbt/NBTTagCompound",
						"setInteger",
						"(Ljava/lang/String;I)V");

					if (!HelperDeobf.isDeobfuscated()) {
						replacement = replacement.remap(Mappings.getMcp2Srg());
					}

					overrideList.add(new MethodInsnNode(TransformerCrops.INVOKEVIRTUAL,
						replacement.owner, replacement.name, replacement.desc));
				}

				// return�߂�LineNumberNode�̑O
				mnode.instructions.insertBefore(mnode.instructions.get(mnode.instructions.size() - 3), overrideList);
			}

		});

		TransformerCrops.entries.add(new TransformEntryMethod(
			new MethodEntry("ic2.core.block.TileEntityCrop".replaceAll("\\.", "/"),
				"readFromNBT",
				"(Lnet/minecraft/nbt/NBTTagCompound;)V"),
			new MethodEntry("net.minecraft.tileentity.TileEntity".replaceAll("\\.", "/"),
				"readFromNBT",
				"(Lnet/minecraft/nbt/NBTTagCompound;)V")) {

			@Override
			public void onTransform(MethodNode mnode)
			{
				InsnList overrideList = new InsnList();

				overrideList.add(new VarInsnNode(Opcodes.ALOAD, 0));
				overrideList.add(new VarInsnNode(Opcodes.ALOAD, 1));
				overrideList.add(new LdcInsnNode("exStorage"));

				{
					MethodEntry replacement = new MethodEntry(
						"net/minecraft/nbt/NBTTagCompound",
						"getInteger",
						"(Ljava/lang/String;)I");

					if (!HelperDeobf.isDeobfuscated()) {
						replacement = replacement.remap(Mappings.getMcp2Srg());
					}

					overrideList.add(new MethodInsnNode(TransformerCrops.INVOKEVIRTUAL,
						replacement.owner, replacement.name, replacement.desc));
				}
				overrideList.add(new FieldInsnNode(Opcodes.PUTFIELD, method.owner, "exStorage", "I"));

				// return�߂�LineNumberNode�̑O
				mnode.instructions.insertBefore(mnode.instructions.get(mnode.instructions.size() - 3), overrideList);
			}

		});

	}

	@Override
	public String[] getASMTransformerClass()
	{
		return instance == this ? new String[] {
			TransformerCrops.class.getName(),
		} : null;
	}

	@Override
	public String getModContainerClass()
	{
		return null;
	}

	@Override
	public String getSetupClass()
	{
		return null;
	}

	@Override
	public void injectData(Map<String, Object> data)
	{

	}

	@Override
	public String getAccessTransformerClass()
	{
		return null;
	}

}
