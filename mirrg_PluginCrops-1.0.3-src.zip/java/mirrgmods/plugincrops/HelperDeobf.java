package mirrgmods.plugincrops;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import mirrgmods.plugincrops.deobf.HelperSrg;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

import cpw.mods.fml.common.FMLLog;

public class HelperDeobf
{

	public static String dummyClassFileName = "/mirrgmods/plugincrops/DummyTileEntity.class";
	private static Boolean isDeobfuscated = null;

	public static boolean isDeobfuscated()
	{
		if (isDeobfuscated == null) {
			URL url = HelperSrg.getResource(dummyClassFileName);

			if (url == null) {
				FMLLog.warning("[PluginCrops] loading error: file not found: '" + dummyClassFileName + "'");
				isDeobfuscated = false;
				return isDeobfuscated;
			}

			try {
				InputStream is = url.openStream();

				ArrayList<byte[]> bytesList = new ArrayList<byte[]>();
				ArrayList<Integer> lengthList = new ArrayList<Integer>();

				while (true) {
					byte[] buf = new byte[2048];

					int res = is.read(buf);

					if (res == -1) {
						break;
					}

					bytesList.add(buf);
					lengthList.add(res);
				}

				int size = 0;
				for (int i = 0; i < lengthList.size(); i++) {
					size += lengthList.get(i);
				}

				byte[] buf = new byte[size];

				int index = 0;
				for (int i = 0; i < bytesList.size(); i++) {
					System.arraycopy(bytesList.get(i), 0, buf, index, lengthList.get(i));
					index += lengthList.get(i);
				}

				ClassNode cnode = new ClassNode();
				ClassReader reader = new ClassReader(buf);
				reader.accept(cnode, 0);

				MethodNode mnode = null;

				for (MethodNode curMnode : cnode.methods) {
					if ("markDirty".equals(curMnode.name) && "()V".equals(curMnode.desc)) {
						mnode = curMnode;
						break;
					}
				}

				isDeobfuscated = mnode != null;
				return isDeobfuscated;

			} catch (IOException e) {
				isDeobfuscated = false;
				return isDeobfuscated;
			}

		}

		return isDeobfuscated;
	}

}
