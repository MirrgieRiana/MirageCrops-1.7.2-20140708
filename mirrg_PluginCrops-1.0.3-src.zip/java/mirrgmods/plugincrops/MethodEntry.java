package mirrgmods.plugincrops;

import org.objectweb.asm.commons.Remapper;

public class MethodEntry
{
	public final String owner;
	public final String name;
	public final String desc;

	/**
	 *
	 * @param owner
	 *            example "java/lang/String"
	 * @param name
	 *            example "toString"
	 * @param desc
	 *            example "()LJava/lang/String;"
	 */
	public MethodEntry(String owner, String name, String desc)
	{
		this.owner = owner;
		this.name = name;
		this.desc = desc;
	}

	public MethodEntry remap(Remapper remapper)
	{
		String owner2 = remapper.map(owner);
		String name2 = remapper.mapMethodName(owner, name, desc);
		String desc2 = remapper.mapMethodDesc(desc);

		return new MethodEntry(owner2, name2, desc2);
	}

	@Override
	public String toString()
	{
		return owner + "/" + name + desc;
	}

}
