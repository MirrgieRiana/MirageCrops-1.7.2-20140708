package mirrgmods.plugincrops.deobf;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import mirrgmods.plugincrops.deobf.HelperSrg.EnumType;
import cpw.mods.fml.common.FMLLog;

public class Mappings
{

	public static final String srgName = "/mirrgmods/plugincrops/deobf/mcp-srg_1.7.2-10.12.2.1147.srg.lzma";

	private static MirrgSrgRemapper mcp2srg;
	private static MirrgSrgRemapper srg2mcp;

	public static void load()
	{
		mcp2srg = new MirrgSrgRemapper();
		srg2mcp = new MirrgSrgRemapper();

		URL url = HelperSrg.getResource(srgName);

		if (url == null) {
			FMLLog.warning("[PluginCrops] loading error: file not found: '" + srgName + "'");
			return;
		}

		FMLLog.info("[PluginCrops] loading srg file: '" + url + "'");

		List<String> lines;

		try {
			lines = HelperSrg.getLines(url, EnumType.LZMA);
		} catch (IOException e) {
			FMLLog.warning("[PluginCrops] loading error: decode error: '" + url + "'");
			e.printStackTrace(System.out);
			return;
		}

		mcp2srg.load(lines, false);
		srg2mcp.load(lines, true);

		FMLLog.info("[PluginCrops] finish loading file: '" + url + "'");
	}

	public static MirrgSrgRemapper getMcp2Srg()
	{
		if (mcp2srg == null) load();
		return mcp2srg;
	}

	public static MirrgSrgRemapper getSrg2Mcp()
	{
		if (srg2mcp == null) load();
		return srg2mcp;
	}

}
