package mirrgmods.plugincrops.transform;

import java.util.ListIterator;

import mirrgmods.plugincrops.HelperDeobf;
import mirrgmods.plugincrops.MethodEntry;
import mirrgmods.plugincrops.deobf.Mappings;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

import cpw.mods.fml.common.FMLLog;

public class TransformEntryMethod extends TransformEntry
{

	public static boolean debug = false;

	protected final MethodEntry method;
	protected final MethodEntry superVanillaMethod;

	public TransformEntryMethod(
		MethodEntry methodEntry,
		MethodEntry superVanillaMethodEntry)
	{
		this.method = methodEntry;
		this.superVanillaMethod = superVanillaMethodEntry;
	}

	@Override
	public byte[] onTransform(String name, String paramString2, byte[] bytes)
	{

		if (!name.replaceAll("\\.", "/").equals(method.owner)) {
			return super.onTransform(name, paramString2, bytes);
		}

		FMLLog.info("[PluginCrops] Transform(" + method + "): begin");

		ClassNode cnode = new ClassNode();
		ClassReader reader = new ClassReader(bytes);
		reader.accept(cnode, 0);

		MethodNode mnode = null;

		if (HelperDeobf.isDeobfuscated()) {

			for (MethodNode curMnode : cnode.methods) {
				if (method.name.equals(curMnode.name) && method.desc.equals(curMnode.desc)) {
					mnode = curMnode;
					break;
				}
			}

		} else {

			for (MethodNode curMnode : cnode.methods) {
				if (method.name.equals(Mappings.getSrg2Mcp().mapMethodName(superVanillaMethod.owner, curMnode.name, curMnode.desc)) &&
					method.desc.equals(Mappings.getSrg2Mcp().mapMethodDesc(curMnode.desc))) {
					mnode = curMnode;
					break;
				}
			}

		}

		if (mnode != null) {

			if (debug) {
				ListIterator<AbstractInsnNode> iterator = mnode.instructions.iterator();
				while (iterator.hasNext()) {
					AbstractInsnNode node = iterator.next();

					String str = "";

					str += node.getClass().getSimpleName();
					str += "[";
					str += node.getOpcode();
					str += "] ";

					if (node instanceof VarInsnNode) {
						str += String.format("%d", ((VarInsnNode) node).var);
					} else if (node instanceof JumpInsnNode) {
						str += String.format("%s", ((JumpInsnNode) node).label.getLabel());
					} else if (node instanceof LabelNode) {
						str += String.format("%s", ((LabelNode) node).getLabel());
					} else if (node instanceof MethodInsnNode) {
						str += String.format("%s %s %s", ((MethodInsnNode) node).owner, ((MethodInsnNode) node).name, ((MethodInsnNode) node).desc);
					} else if (node instanceof InsnNode) {
						str += String.format("%d", ((InsnNode) node).getType());
					} else if (node instanceof IntInsnNode) {
						str += String.format("%d", ((IntInsnNode) node).operand);
					} else if (node instanceof FieldInsnNode) {
						str += String.format("%s %s %s", ((FieldInsnNode) node).owner, ((FieldInsnNode) node).name, ((FieldInsnNode) node).desc);
					} else if (node instanceof LdcInsnNode) {
						str += String.format("%s %s", ((LdcInsnNode) node).cst.getClass(), ((LdcInsnNode) node).cst);
					} else if (node instanceof LineNumberNode) {
						str += String.format("<<<<< %d >>>>>", ((LineNumberNode) node).line);
					} else {
						str += String.format("%s %d", node.toString(), node.getType());
					}

					System.out.println(str);
				}
			}

			onTransform(mnode);

			ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
			cnode.accept(cw);
			bytes = cw.toByteArray();

			FMLLog.info("[PluginCrops] Transform(" + method + "): end");
		} else {
			FMLLog.info("[PluginCrops] Transform(" + method + "): error: not found");
		}

		return bytes;
	}

	public void onTransform(MethodNode mnode)
	{

	}

}
