package mirrgmods.plugincrops.transform;

import mirrgmods.plugincrops.HelperDeobf;
import mirrgmods.plugincrops.MethodEntry;
import mirrgmods.plugincrops.TransformerCrops;
import mirrgmods.plugincrops.deobf.Mappings;

import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class TransformEntryMethodRedirection extends TransformEntryMethod
{

	protected final String replacementClassName;
	protected final int[] argumentOpcodes;
	protected final int returnOpcode;

	public TransformEntryMethodRedirection(
		MethodEntry method,
		MethodEntry superVanillaMethod,
		String replacementClassName,
		int[] argumentOpcodes,
		int returnOpcode)
	{
		super(method, superVanillaMethod);

		this.replacementClassName = replacementClassName;
		this.argumentOpcodes = argumentOpcodes;
		this.returnOpcode = returnOpcode;
	}

	@Override
	public void onTransform(MethodNode mnode)
	{
		InsnList overrideList = new InsnList();

		for (int i = 0; i < argumentOpcodes.length; i++) {
			overrideList.add(new VarInsnNode(argumentOpcodes[i], 1 + i));
		}

		{
			MethodEntry replacement = new MethodEntry(replacementClassName, method.name, method.desc);

			if (!HelperDeobf.isDeobfuscated()) {
				replacement = replacement.remap(Mappings.getMcp2Srg());
			}

			overrideList.add(new MethodInsnNode(TransformerCrops.INVOKESTATIC,
				replacement.owner, replacement.name, replacement.desc));
		}

		overrideList.add(new InsnNode(returnOpcode));

		// LineNumberNode�̌�
		mnode.instructions.insert(mnode.instructions.get(1), overrideList);
	}

}
