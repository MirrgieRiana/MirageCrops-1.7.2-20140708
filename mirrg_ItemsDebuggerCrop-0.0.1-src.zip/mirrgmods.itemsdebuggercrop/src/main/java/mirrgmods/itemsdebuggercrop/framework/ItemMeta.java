package mirrgmods.itemsdebuggercrop.framework;

import java.util.List;

import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ItemMeta<T extends MetaItem<?>> extends Item
{

	T[] metaItems;

	public ItemMeta(T[] array)
	{
		metaItems = array;
		setHasSubtypes(true);
	}

	public T getMetaItem(int meta)
	{
		if (metaItems[meta] == null) return metaItems[0];
		return metaItems[meta];
	}

	public T getMetaItem(ItemStack itemStack)
	{
		if (itemStack == null) return getMetaItem(0);
		return getMetaItem(itemStack.getItemDamage());
	}

	public void setMetaItem(int id, T metaItem)
	{
		metaItems[id] = metaItem;
	}

	//

	@Override
	@SideOnly(Side.CLIENT)
	public void getSubItems(Item p_150895_1_, CreativeTabs p_150895_2_, List p_150895_3_)
	{
		for (int i = 0; i < metaItems.length; i++) {
			if (metaItems[i] != null) {
				metaItems[i].getSubItems(p_150895_1_, p_150895_2_, p_150895_3_);
			}
		}
	}

	public String getRegisterName()
	{
		return getUnlocalizedName().substring(5);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public boolean requiresMultipleRenderPasses()
	{
		return true;
	}

	@Override
	public int getRenderPasses(int metadata)
	{
		return getMetaItem(metadata).getRenderPasses(metadata);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		for (int i = 0; i < metaItems.length; i++) {
			if (metaItems[i] != null) {
				metaItems[i].registerIcons(par1IconRegister);
			}
		}
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return getMetaItem(stack).getIcon(stack, pass);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public int getColorFromItemStack(ItemStack par1ItemStack, int par2)
	{
		return getMetaItem(par1ItemStack).getColorFromItemStack(par1ItemStack, par2);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4)
	{
		getMetaItem(par1ItemStack).addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);
	}

	@Override
	public String getItemStackDisplayName(ItemStack par1ItemStack)
	{
		return getMetaItem(par1ItemStack).getItemStackDisplayName(par1ItemStack);
	}

	@Override
	public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
	{
		return getMetaItem(par1ItemStack).onItemUse(par1ItemStack, par2EntityPlayer, par3World, par4, par5, par6, par7, par8, par9, par10);
	}

}
