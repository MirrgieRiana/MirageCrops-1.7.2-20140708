package mirrgmods.itemsdebuggercrop.framework;

import java.util.List;

import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public abstract class MetaItem<T extends ItemMeta<?>>
{

	public T itemMeta;
	public int metaId;
	public String unlocalizedName;

	public void setItemMeta(T itemMeta)
	{
		this.itemMeta = itemMeta;
	}

	public void setMetaId(int metaId)
	{
		this.metaId = metaId;
	}

	public T getItemMeta()
	{
		return itemMeta;
	}

	public int getMetaId()
	{
		return metaId;
	}

	public void setUnlocalizedName(String unlocalizedName)
	{
		this.unlocalizedName = unlocalizedName;
	}

	//
	//

	@SideOnly(Side.CLIENT)
	public void getSubItems(Item p_150895_1_, CreativeTabs p_150895_2_, List<ItemStack> p_150895_3_)
	{
		p_150895_3_.add(new ItemStack(p_150895_1_, 1, metaId));
	}

	public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
	{
		return false;
	}

	public String getItemStackDisplayName(ItemStack par1ItemStack)
	{
		return ("" + StatCollector.translateToLocal(this.getUnlocalizedNameInefficiently(par1ItemStack) + ".name")).trim();
	}

	public String getUnlocalizedNameInefficiently(ItemStack par1ItemStack)
	{
		String s = this.getUnlocalizedName(par1ItemStack);
		return s == null ? "" : StatCollector.translateToLocal(s);
	}

	public String getUnlocalizedName(ItemStack par1ItemStack)
	{
		return "item." + this.unlocalizedName;
	}

	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List<String> par3List, boolean par4)
	{

	}

	public int getColorFromItemStack(ItemStack par1ItemStack, int par2)
	{
		return 16777215;
	}

	public abstract IIcon getIcon(ItemStack stack, int pass);

	public abstract void registerIcons(IIconRegister par1IconRegister);

	public int getRenderPasses(int metadata)
	{
		return 1;
	}

}
