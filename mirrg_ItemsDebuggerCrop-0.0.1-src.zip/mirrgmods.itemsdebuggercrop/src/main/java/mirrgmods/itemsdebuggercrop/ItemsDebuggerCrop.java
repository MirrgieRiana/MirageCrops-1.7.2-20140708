package mirrgmods.itemsdebuggercrop;

import mirrg.mir34.modding.ModAbstract;
import mirrg.mir34.modding.example.ExampleMod;
import mirrgmods.itemsdebuggercrop.core.ModuleCore;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

@Mod(
	modid = ItemsDebuggerCrop.MODID,
	version = ItemsDebuggerCrop.VERSION,
	name = ItemsDebuggerCrop.NAME,
	dependencies = ItemsDebuggerCrop.DEPENDENCIES)
public class ItemsDebuggerCrop extends ModAbstract
{

	public static final String MODID = "mirrg_ItemsDebuggerCrop";
	public static final String VERSION = "0.0.1";
	public static final String NAME = "ItemsDebuggerCrop";
	public static final String DEPENDENCIES =
		"";

	@Instance(ExampleMod.MODID)
	public static ExampleMod instance;

	@Override
	protected void loadModules()
	{
		addModule(new ModuleCore(this));
	}

	@Override
	@EventHandler
	public void handle(FMLPreInitializationEvent event)
	{
		super.handle(event);
	}

	@Override
	@EventHandler
	public void handle(FMLInitializationEvent event)
	{
		super.handle(event);
	}

	@Override
	@EventHandler
	public void handle(FMLPostInitializationEvent event)
	{
		super.handle(event);
	}

}
