package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;
import mirrgmods.itemsdebuggercrop.framework.EnumNBTTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class StackEntityDebuggerCropPicker
{
	public int id;
	public int growth;
	public int gain;
	public int resistance;
	public int scanLevel;
	public int size;

	{
		reset();
	}

	public void reset()
	{
		id = -1;
		growth = 0;
		gain = 0;
		resistance = 0;
		scanLevel = 0;
		size = 1;
	}

	public void readFromItemStack(ItemStack itemStack)
	{
		reset();

		if (itemStack.hasTagCompound()) {
			readFromNBT(itemStack.getTagCompound());
		}
	}

	public void writeToItemStack(ItemStack itemStack)
	{
		NBTTagCompound nbt = new NBTTagCompound();
		writeToNBT(nbt);
		itemStack.setTagCompound(nbt);
	}

	public void readFromNBT(NBTTagCompound nbt)
	{
		reset();

		if (nbt.hasKey("id", EnumNBTTypes.INT.ordinal())) {
			id = nbt.getInteger("id");
		}
		if (nbt.hasKey("growth", EnumNBTTypes.INT.ordinal())) {
			growth = nbt.getInteger("growth");
		}
		if (nbt.hasKey("gain", EnumNBTTypes.INT.ordinal())) {
			gain = nbt.getInteger("gain");
		}
		if (nbt.hasKey("resistance", EnumNBTTypes.INT.ordinal())) {
			resistance = nbt.getInteger("resistance");
		}
		if (nbt.hasKey("scanLevel", EnumNBTTypes.INT.ordinal())) {
			scanLevel = nbt.getInteger("scanLevel");
		}
		if (nbt.hasKey("size", EnumNBTTypes.INT.ordinal())) {
			size = nbt.getInteger("size");
		}
	}

	public void writeToNBT(NBTTagCompound nbt)
	{
		nbt.setInteger("id", id);
		nbt.setInteger("growth", growth);
		nbt.setInteger("gain", gain);
		nbt.setInteger("resistance", resistance);
		nbt.setInteger("scanLevel", scanLevel);
		nbt.setInteger("size", size);
	}

	public boolean isEmpty()
	{
		return id == -1;
	}

	public void readFromTile(ICropTile tile)
	{
		reset();

		id = tile.getID();
		growth = tile.getGrowth();
		gain = tile.getGain();
		resistance = tile.getResistance();
		scanLevel = tile.getScanLevel();
		size = tile.getSize();
	}

	public void writeToTile(ICropTile tile)
	{
		tile.setID((short) id);
		tile.setGrowth((byte) growth);
		tile.setGain((byte) gain);
		tile.setResistance((byte) resistance);
		tile.setScanLevel((byte) scanLevel);
		tile.setSize((byte) size);
	}

	/**
	 * growth: green<br>
	 * gain: red<br>
	 * resistance: blue
	 */
	public int getColor()
	{
		int r = gain * 256 / 31;
		int g = growth * 256 / 31;
		int b = resistance * 256 / 31;
		r = Math.max(Math.min(r, 255), 0);
		g = Math.max(Math.min(g, 255), 0);
		b = Math.max(Math.min(b, 255), 0);

		return (r << 16) | (g << 8) | b;
	}

	public CropCard getCropCardOrNull()
	{
		CropCard cropCard = null;

		if (id < 0) return null;
		if (Crops.instance == null) return null;
		if (Crops.instance.getCropList() == null) return null;
		if (id >= Crops.instance.getCropList().length) return null;

		return Crops.instance.getCropList()[id];
	}

}
