package mirrgmods.itemsdebuggercrop.core;

import mirrgmods.itemsdebuggercrop.framework.EnumNBTTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class StackEntityDebuggerCropSandglass
{
	public int range;
	public int times;

	{
		reset();
	}

	public void reset()
	{
		range = 0;
		times = 1;
	}

	public void readFromItemStack(ItemStack itemStack)
	{
		reset();

		if (itemStack.hasTagCompound()) {
			readFromNBT(itemStack.getTagCompound());
		}
	}

	public void writeToItemStack(ItemStack itemStack)
	{
		NBTTagCompound nbt = new NBTTagCompound();
		writeToNBT(nbt);
		itemStack.setTagCompound(nbt);
	}

	public void readFromNBT(NBTTagCompound nbt)
	{
		reset();

		if (nbt.hasKey("range", EnumNBTTypes.INT.ordinal())) {
			range = nbt.getInteger("range");
		}
		if (nbt.hasKey("times", EnumNBTTypes.INT.ordinal())) {
			times = nbt.getInteger("times");
		}
	}

	public void writeToNBT(NBTTagCompound nbt)
	{
		nbt.setInteger("range", range);
		nbt.setInteger("times", times);
	}

}
