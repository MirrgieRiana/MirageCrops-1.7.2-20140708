package mirrgmods.itemsdebuggercrop.core;

import static net.minecraft.util.EnumChatFormatting.*;
import ic2.api.crops.CropCard;
import ic2.api.crops.ICropTile;

import java.util.List;

import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import scala.util.Random;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropPicker extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;
	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon2;
	protected String iconString2;
	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon3;
	protected String iconString3;

	public MetaItemDebuggerCropPicker(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
		iconString2 = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName + "_2";
		iconString3 = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName + "_3";
	}

	@Override
	public int getRenderPasses(int metadata)
	{
		return 3;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
		itemIcon2 = par1IconRegister.registerIcon(iconString2);
		itemIcon3 = par1IconRegister.registerIcon(iconString3);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		if (pass == 1) {
			StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
			stackEntity.readFromItemStack(stack);
			if (stackEntity.isEmpty()) return itemIcon;
			return itemIcon2;
		} else if (pass == 2) {
			StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
			stackEntity.readFromItemStack(stack);
			if (stackEntity.isEmpty()) return itemIcon;
			return itemIcon3;
		}
		return itemIcon;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public int getColorFromItemStack(ItemStack par1ItemStack, int par2)
	{
		if (par2 == 1) {
			StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
			stackEntity.readFromItemStack(par1ItemStack);
			if (stackEntity.isEmpty()) return 0xffffff;
			return stackEntity.getColor();
		} else if (par2 == 2) {
			StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
			stackEntity.readFromItemStack(par1ItemStack);
			if (stackEntity.isEmpty()) return 0xffffff;

			int color = new Random(stackEntity.id).nextInt() & 0xffffff;
			return color;
		}
		return super.getColorFromItemStack(par1ItemStack, par2);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List<String> par3List, boolean par4)
	{
		super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);

		StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
		stackEntity.readFromItemStack(par1ItemStack);

		if (stackEntity.isEmpty()) {
			par3List.add("  " + RED + "Empty");
		} else {

			CropCard cropCard = stackEntity.getCropCardOrNull();

			if (cropCard != null) {
				par3List.add("    " + WHITE + "--  " + cropCard.name() + "  --");
				par3List.add(String.format("" + GRAY + "DiscoveredBy: %s",
					cropCard.discoveredBy()));
				par3List.add(String.format("" + GRAY + "  %s",
					cropCard.desc(0)));
				par3List.add(String.format("" + GRAY + "  %s",
					cropCard.desc(1)));
				par3List.add(String.format("" + YELLOW + "Tier: %s",
					cropCard.tier()));
				par3List.add(String.format("" + GRAY + "Stat: %s %s %s %s %s",
					cropCard.stat(0),
					cropCard.stat(1),
					cropCard.stat(2),
					cropCard.stat(3),
					cropCard.stat(4)));
			} else {
				par3List.add("    " + RED + "Invalid crop id!!");
			}

			par3List.add("");

			par3List.add("  " + GRAY + "Id: " + stackEntity.id);

			par3List.add(String.format("  " + GRAY + "( " + GREEN + "Gr" + GRAY + ", " + GOLD + "Ga" + GRAY + ", " + AQUA + "Re" + GRAY + " ): " +
				GRAY + "( " + GREEN + "%s" + GRAY + ", " + GOLD + "%s" + GRAY + ", " + AQUA + "%s" + GRAY + " )",
				stackEntity.growth,
				stackEntity.gain,
				stackEntity.resistance));

			{
				boolean invalid = false;
				if (stackEntity.size < 1) invalid = true;
				if (cropCard != null && stackEntity.size > cropCard.maxSize()) invalid = true;
				String color = "" + (invalid ? RED : GRAY);

				if (cropCard != null) {
					par3List.add(String.format("  " + color + "Size: %s / %s",
						stackEntity.size,
						cropCard.maxSize()));
				} else {
					par3List.add(String.format("  " + color + "Size: %s",
						stackEntity.size));
				}
			}

			par3List.add("  " + GRAY + "ScanLevel: " + stackEntity.scanLevel);

		}

	}

	@Override
	public String getItemStackDisplayName(ItemStack par1ItemStack)
	{
		StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
		stackEntity.readFromItemStack(par1ItemStack);

		if (stackEntity.isEmpty()) {
			return super.getItemStackDisplayName(par1ItemStack);
		} else {
			CropCard cropCard = stackEntity.getCropCardOrNull();
			if (cropCard == null) {
				return super.getItemStackDisplayName(par1ItemStack) + " - Invalid Id";
			} else {
				return super.getItemStackDisplayName(par1ItemStack) +
					String.format(" - %s:%d %d %d %d",
						cropCard.name(),
						stackEntity.size,
						stackEntity.growth,
						stackEntity.gain,
						stackEntity.resistance);
			}
		}
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		{
			TileEntity tileEntiry = world.getTileEntity(x, y, z);
			if (tileEntiry instanceof ICropTile) {
				ICropTile cropTile = (ICropTile) tileEntiry;

				if (cropTile.getID() >= 0) {
					// read
					StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
					stackEntity.readFromTile(cropTile);
					stackEntity.writeToItemStack(itemStack);
				} else {
					// write
					StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
					stackEntity.readFromItemStack(itemStack);
					stackEntity.writeToTile(cropTile);
				}

				return true;
			}
		}

		{
			Block block = world.getBlock(x, y, z);

			boolean valid = false;
			int tag = 0;
			int addition = 0;

			if (block == Blocks.sandstone) {
				valid = true;
				tag = 1;
				addition = 1;
			} else if (block == Blocks.grass) {
				valid = true;
				tag = 1;
				addition = -1;
			} else if (block == Blocks.stone) {
				valid = true;
				tag = 2;
				addition = 1;
			} else if (block == Blocks.cobblestone) {
				valid = true;
				tag = 2;
				addition = -1;
			} else if (block == Blocks.log) {
				valid = true;
				tag = 3;
				addition = 1;
			} else if (block == Blocks.planks) {
				valid = true;
				tag = 3;
				addition = -1;
			} else if (block == Blocks.glass) {
				valid = true;
				tag = 4;
				addition = 1;
			} else if (block == Blocks.sand) {
				valid = true;
				tag = 4;
				addition = -1;
			} else if (block == Blocks.gravel) {
				valid = true;
				tag = 5;
			} else if (block == Blocks.iron_ore) {
				valid = true;
				tag = 6;
				addition = 1;
			} else if (block == Blocks.gold_ore) {
				valid = true;
				tag = 6;
				addition = -1;
			}

			if (player != null && player.isSneaking()) {
				addition *= 5;
			}

			if (valid) {
				StackEntityDebuggerCropPicker stackEntity = new StackEntityDebuggerCropPicker();
				stackEntity.readFromItemStack(itemStack);
				String message = null;

				if (tag == 1) {
					stackEntity.growth += addition;
					message = "Growth: " + stackEntity.growth;
				} else if (tag == 2) {
					stackEntity.gain += addition;
					message = "Gain: " + stackEntity.gain;
				} else if (tag == 3) {
					stackEntity.resistance += addition;
					message = "Resistance: " + stackEntity.resistance;
				} else if (tag == 4) {
					stackEntity.id += addition;
					message = "Id: " + stackEntity.id;
				} else if (tag == 5) {
					stackEntity.reset();
					message = "Reset Picker";
				} else if (tag == 6) {
					stackEntity.size += addition;
					message = "Size: " + stackEntity.size;
				}

				stackEntity.writeToItemStack(itemStack);

				if (message != null) {
					if (player instanceof EntityPlayerMP) {
						IChatComponent msg = new ChatComponentTranslation(message);
						((EntityPlayerMP) player).addChatMessage(msg);
					}
				}

			}

		}

		return false;
	}

}
