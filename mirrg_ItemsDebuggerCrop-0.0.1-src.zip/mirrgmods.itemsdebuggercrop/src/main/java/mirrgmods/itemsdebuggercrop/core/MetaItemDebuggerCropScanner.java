package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;

import java.lang.reflect.InvocationTargetException;

import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropScanner extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropScanner(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (world == null) return false;
		if (world.isRemote) return false;

		HelperCrop.sendChatToPlayer(player, "-- Scanning ---------");

		{
			Block block = world.getBlock(x, y, z);
			int blockId = Block.getIdFromBlock(block);
			int metadata = world.getBlockMetadata(x, y, z);

			HelperCrop.sendChatToPlayer(player,
				String.format("[Block] xyz: (%d, %d, %d) id: (%d:%d) BlcLightVal: %d",
					x,
					y,
					z,
					blockId,
					metadata,
					world.getBlockLightValue(x, y, z)));

			{
				Item item = Item.getItemFromBlock(block);

				if (item == null) {
					HelperCrop.sendChatToPlayer(player, "[ItemBlock] null");
				} else {
					HelperCrop.sendChatToPlayer(player,
						String.format("[ItemBlock] name: %s(%s) class:%s",
							new ItemStack(item, 1, metadata).getUnlocalizedName(),
							new ItemStack(item, 1, metadata).getDisplayName(),
							block.getClass().getName()));
				}
			}
		}

		TileEntity te = world.getTileEntity(x, y, z);

		if (te == null) {
			HelperCrop.sendChatToPlayer(
				player,
				String.format("[TileEntity] null"));
		} else {

			HelperCrop.sendChatToPlayer(
				player,
				String.format("[TileEntity] " + te.getClass().getName()));

			if (te instanceof ICropTile) {

				ICropTile tec = (ICropTile) te;

				HelperCrop.sendChatToPlayer(
					player,
					String.format("[TileEntityCrop] id: %d upgraded: %s ticker: %d(%d) dirty: %s",
						(int) tec.getID(),
						"" + HelperCrop.isUpgraded(tec),
						(int) HelperCrop.getTicker(tec),
						255 - (HelperCrop.getTicker(tec) - 1) % 256,
						"" + HelperCrop.isDirty(tec)));

				HelperCrop.sendChatToPlayer(
					player,
					String.format("  HumNutAir: (%d, %d, %d) WatNutWEx: (%d, %d, %d)",
						(int) tec.getHumidity(),
						(int) tec.getNutrients(),
						(int) tec.getAirQuality(),
						tec.getHydrationStorage(),
						tec.getNutrientStorage(),
						tec.getWeedExStorage()));

				if (tec.getID() >= 0) {
					CropCard card = Crops.instance.getCropList()[tec.getID()];

					HelperCrop.sendChatToPlayer(
						player,
						String.format("[CropCard] id: %d(%s:%d) size: %d/%d growthPoints: %d/%d",
							(int) tec.getID(),
							card.name(),
							card.tier(),
							(int) tec.getSize(),
							card.maxSize(),
							HelperCrop.getGrowthPoints(tec),
							card.growthDuration(tec)));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  CropCard ClassName: %s",
							card.getClass().getName()));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  GGR: (%d, %d, %d) scanLebel: %d",
							(int) tec.getGrowth(),
							(int) tec.getGain(),
							(int) tec.getResistance(),
							(int) tec.getScanLevel()));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  canBeHarvested: %s canCross: %s canGrow: %s",
							"" + card.canBeHarvested(tec),
							"" + card.canCross(tec),
							"" + card.canGrow(tec)));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  dropGain: %f dropSeed: %f duration: %d weightInflu: %d",
							(double) card.dropGainChance(),
							(double) card.dropSeedChance(tec),
							card.growthDuration(tec),
							card.weightInfluences(
								tec,
								tec.getHumidity(),
								tec.getNutrients(),
								tec.getAirQuality())));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  isWeed: %s sizeAfterHarvest: %d",
							"" + card.isWeed(tec),
							(int) card.getSizeAfterHarvest(tec)));

					HelperCrop.sendChatToPlayer(
						player,
						String.format("  growBase: [%d -> %d] need: %d have: %d",
							3 + 0 + tec.getGrowth(),
							3 + 6 + tec.getGrowth(),
							(card.tier() - 1) * 4 +
								tec.getGrowth() + tec.getGain() + tec.getResistance(),
							card.weightInfluences(
								tec,
								tec.getHumidity(),
								tec.getNutrients(),
								tec.getAirQuality()) * 5));

					{
						String multiCulture;

						try {
							byte mc = (Byte) tec.getClass().getMethod("updateMultiCulture").invoke(tec);
							multiCulture = "" + mc;
						} catch (NullPointerException e) {
							multiCulture = e.toString();
						} catch (ArrayIndexOutOfBoundsException e) {
							multiCulture = e.toString();
						} catch (IllegalArgumentException e) {
							multiCulture = e.toString();
						} catch (SecurityException e) {
							multiCulture = e.toString();
						} catch (IllegalAccessException e) {
							multiCulture = e.toString();
						} catch (InvocationTargetException e) {
							multiCulture = e.toString();
						} catch (NoSuchMethodException e) {
							multiCulture = e.toString();
						}

						HelperCrop.sendChatToPlayer(
							player,
							String.format("  multiCulture: %s",
								multiCulture));
					}

				}

			}
		}

		return true;
	}

}
