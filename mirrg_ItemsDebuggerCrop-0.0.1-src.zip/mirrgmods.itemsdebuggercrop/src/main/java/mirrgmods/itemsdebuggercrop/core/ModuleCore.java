package mirrgmods.itemsdebuggercrop.core;

import mirrg.mir34.modding.IMod;
import mirrg.mir34.modding.ModuleAbstract;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class ModuleCore extends ModuleAbstract
{

	public static ModuleCore instance;

	public ModuleCore(IMod mod)
	{
		super(mod);
		instance = this;
	}

	@SideOnly(Side.CLIENT)
	public static CreativeTabs creativeTab;

	@Override
	@SideOnly(Side.CLIENT)
	public void handlePreClient(FMLPreInitializationEvent event)
	{
		creativeTab = new CreativeTabs("mirrgmods.itemsdebuggercrop.core") {

			@Override
			@SideOnly(Side.CLIENT)
			public Item getTabIconItem()
			{
				return itemDebuggerCrop;
			}

		};
	}

	public static ItemMeta<?> itemDebuggerCrop;
	public static MetaItemDebuggerCropPicker MetaItemDebuggerCropPicker;

	@Override
	public void handle(FMLPostInitializationEvent event)
	{

	}

	@Override
	public void handle(FMLInitializationEvent event)
	{

	}

	@Override
	public void handle(FMLPreInitializationEvent event)
	{
		ItemMeta<MetaItem<?>> item =
			new ItemMeta<MetaItem<?>>((MetaItem<?>[]) new MetaItem<?>[256]);
		item.setUnlocalizedName("craftingDebuggerCrop");
		item.setCreativeTab(creativeTab);

		{
			MetaItemDebuggerCropPicker metaItem = new MetaItemDebuggerCropPicker("craftingDebuggerCropPicker");
			int metaId = 0;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropPicker");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropSandglass metaItem = new MetaItemDebuggerCropSandglass("craftingDebuggerCropSandglass");
			int metaId = 1;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropSandglass");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropScanner metaItem = new MetaItemDebuggerCropScanner("craftingDebuggerCropScanner");
			int metaId = 2;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropScanner");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropScannerNBT metaItem = new MetaItemDebuggerCropScannerNBT("craftingDebuggerCropScanner");
			int metaId = 3;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropScannerNBT");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropHarvester metaItem = new MetaItemDebuggerCropHarvester("craftingDebuggerCropHarvester");
			int metaId = 4;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropHarvester");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropHarvesterSeed metaItem = new MetaItemDebuggerCropHarvesterSeed("craftingDebuggerCropHarvesterSeed");
			int metaId = 5;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropHarvesterSeed");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropCrosser metaItem = new MetaItemDebuggerCropCrosser("craftingDebuggerCropCrosser");
			int metaId = 6;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropCrosser");
			item.setMetaItem(metaId, metaItem);
		}

		{
			MetaItemDebuggerCropCrosserDumper metaItem = new MetaItemDebuggerCropCrosserDumper("craftingDebuggerCropCrosser");
			int metaId = 7;
			metaItem.setItemMeta(item);
			metaItem.setMetaId(metaId);
			metaItem.setUnlocalizedName("craftingDebuggerCropCrosserDumper");
			item.setMetaItem(metaId, metaItem);
		}

		GameRegistry.registerItem(item, item.getRegisterName(), getMod().getModId());
		itemDebuggerCrop = item;
	}

	@Override
	public String getModuleName()
	{
		return "core";
	}

}
