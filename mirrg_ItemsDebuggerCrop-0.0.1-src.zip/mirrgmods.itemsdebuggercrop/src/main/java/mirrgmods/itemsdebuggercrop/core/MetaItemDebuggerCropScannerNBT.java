package mirrgmods.itemsdebuggercrop.core;

import java.util.Iterator;

import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropScannerNBT extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropScannerNBT(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public int getColorFromItemStack(ItemStack par1ItemStack, int par2)
	{
		return 0xff88ff;
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (world == null) return false;
		if (world.isRemote) return false;

		TileEntity te = world.getTileEntity(x, y, z);

		if (te == null) {
			HelperCrop.sendChatToPlayer(
				player,
				String.format("[TileEntity] null"));
		} else {

			HelperCrop.sendChatToPlayer(
				player,
				String.format("[TileEntity] " + te.getClass().getName()));

			{
				NBTTagCompound nbt = new NBTTagCompound();
				te.writeToNBT(nbt);

				Iterator<String> iterator = nbt.func_150296_c().iterator();

				HelperCrop.sendChatToPlayer(player, "[TileEntity NBT]");

				while (iterator.hasNext())
				{
					String s = iterator.next();
					NBTBase nbtbase = nbt.getTag(s);
					HelperCrop.sendChatToPlayer(player,
						String.format("  %s : %s = %s",
							s,
							nbtbase.getClass().getSimpleName().substring(3),
							nbtbase));
				}
			}
		}

		return true;
	}

}
