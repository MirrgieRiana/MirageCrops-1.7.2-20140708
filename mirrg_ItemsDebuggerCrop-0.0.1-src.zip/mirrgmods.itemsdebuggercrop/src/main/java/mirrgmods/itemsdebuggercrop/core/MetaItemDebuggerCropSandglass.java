package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;

import java.util.List;

import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropSandglass extends MetaItem<ItemMeta<? super MetaItemDebuggerCropSandglass>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropSandglass(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List<String> par3List, boolean par4)
	{
		super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);

		int range;
		int times;
		{
			StackEntityDebuggerCropSandglass stackEntity = new StackEntityDebuggerCropSandglass();
			stackEntity.readFromItemStack(par1ItemStack);
			range = stackEntity.range;
			times = stackEntity.times;
		}

		par3List.add("Range: " + range);
		par3List.add("Times: " + times);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void getSubItems(Item p_150895_1_, CreativeTabs p_150895_2_, List<ItemStack> p_150895_3_)
	{
		int[][] table = {
			{
				0, 1
			}, {
				0, 5
			}, {
				0, 10
			}, {
				0, 50
			}, {
				0, 100
			}, {
				0, 500
			}, {
				0, 1000
			},
			{
				1, 1
			}, {
				1, 5
			}, {
				1, 10
			}, {
				1, 50
			}, {
				1, 100
			},
			{
				2, 1
			}, {
				2, 5
			}, {
				2, 10
			},
			{
				3, 1
			},
			{
				5, 1
			},
			{
				7, 1
			}, {
				7, 100
			},
		};

		for (int[] entry : table) {
			int range = entry[0];
			int times = entry[1];

			ItemStack itemStack = new ItemStack(p_150895_1_, 1, getMetaId());
			{
				StackEntityDebuggerCropSandglass stackEntiry = new StackEntityDebuggerCropSandglass();
				stackEntiry.range = range;
				stackEntiry.times = times;
				stackEntiry.writeToItemStack(itemStack);
			}
			p_150895_3_.add(itemStack);
		}

	}

	@Override
	public String getItemStackDisplayName(ItemStack par1ItemStack)
	{
		StackEntityDebuggerCropSandglass stackEntiry = new StackEntityDebuggerCropSandglass();
		stackEntiry.readFromItemStack(par1ItemStack);

		return super.getItemStackDisplayName(par1ItemStack) + " - R:" + stackEntiry.range + " T:" + stackEntiry.times;
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (!world.isRemote) {

			int range;
			int times;
			{
				StackEntityDebuggerCropSandglass stackEntity = new StackEntityDebuggerCropSandglass();
				stackEntity.readFromItemStack(itemStack);
				range = stackEntity.range;
				times = stackEntity.times;
			}

			for (int xi = -range; xi <= range; xi++) {
				for (int zi = -range; zi <= range; zi++) {
					for (int yi = -range / 2; yi <= range / 2; yi++) {

						TileEntity tileEntiry = world.getTileEntity(x + xi, y + yi, z + zi);
						if (tileEntiry instanceof ICropTile) {
							ICropTile cropTile = (ICropTile) tileEntiry;

							String[] res = grow(cropTile, times);
							if (res != null) {

								if (xi == 0 && yi == 0 && zi == 0) {
									if (player instanceof EntityPlayerMP) {
										for (String str : res) {
											IChatComponent msg = new ChatComponentTranslation(str);
											((EntityPlayerMP) player).addChatMessage(msg);
										}
									}
								}

								world.playAuxSFX(2005, x + xi, y + yi, z + zi, 0);
							}

						}

					}
				}
			}

		}

		return true;
	}

	protected int[] getGrowParameters(ICropTile cropTile)
	{
		if (cropTile.getID() >= 0) {
			CropCard cropCard = Crops.instance.getCropList()[cropTile.getID()];
			return new int[] {
				cropTile.getSize(),
				HelperCrop.getGrowthPoints(cropTile),
				cropCard.growthDuration(cropTile),
			};
		}
		return null;
	}

	protected void setGrowParameters(ICropTile cropTile, byte size, int gp, boolean dirty)
	{
		cropTile.setSize(size);
		HelperCrop.setGrowthPoints(cropTile, gp);
		if (dirty) HelperCrop.setDirty(cropTile, true);
	}

	/**
	 * @return null: 成長途中で死んだ、植物が無い、もう成長できない<br>
	 *         整数: 成長した
	 */
	protected Integer grow(ICropTile cropTile)
	{
		if (cropTile.getID() == -1) return null;

		CropCard cropCard = Crops.instance.getCropList()[cropTile.getID()];
		if (!cropCard.canGrow(cropTile)) return null;

		int[] size_gp_duration = getGrowParameters(cropTile);

		int size = size_gp_duration[0];
		int gp = size_gp_duration[1];
		int duration = size_gp_duration[2];

		int add = HelperCrop.calcGrowthRate(cropTile);
		if (cropTile.getID() == -1) return null;

		boolean dirty = false;

		gp += add;
		if (gp >= duration) {
			gp = 0;
			size++;
			dirty = true;
		}

		setGrowParameters(cropTile, (byte) size, gp, dirty);

		return add;
	}

	protected String[] grow(ICropTile cropTile, int times)
	{
		int[] begin = getGrowParameters(cropTile);

		if (begin == null) return null;

		if (times == 1) {

			Integer add = grow(cropTile);

			if (add == null) return new String[] {
				String.format("[SandGlass] size: %d gp: %d / %d [can not grow]",
					begin[0],
					begin[1],
					begin[2])
			};

			int[] end = getGrowParameters(cropTile);
			return new String[] {
				String.format("[SandGlass] size: %d -> %d gp: %d / %d -> %d / %d(+%d)",
					begin[0],
					end[0],
					begin[1],
					begin[2],
					end[1],
					end[2],
					add.intValue())
			};
		} else {

			int add_max = 0;
			int add_min = 0;
			int add_sum = 0;
			int add_count = 0;

			for (int i = 0; i < times; i++) {
				Integer add = grow(cropTile);
				if (add == null) break;

				if (i == 0) {
					add_max = add;
					add_min = add;
				} else {
					if (add < add_min) add_min = add;
					if (add > add_max) add_max = add;
				}
				add_sum += add;
				add_count++;
			}

			int[] end = getGrowParameters(cropTile);
			return new String[] {
				String.format("[SandGlass] size: %d -> %d gp: %d / %d -> %d / %d",
					begin[0],
					end[0],
					begin[1],
					begin[2],
					end[1],
					end[2]),
				String.format("Average: %.4f Sum: %d Count: %d Min: %d Max: %d",
					(double) add_sum / add_count,
					add_sum,
					add_count,
					add_min,
					add_max),
			};
		}

	}

}
