package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropCrosser extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropCrosser(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (world == null) return false;
		if (world.isRemote) return false;

		{
			TileEntity te = world.getTileEntity(x, y, z);
			if (te != null) {

				if (te instanceof ICropTile) {
					ICropTile tec = (ICropTile) te;

					{
						tec.setID((short) -1);
						HelperCrop.setUpgraded(tec, true);

						Hashtable<String, Integer> hash = new Hashtable<String, Integer>();

						for (int i = 0; i < getTimes(itemStack); i++) {

							if (tec.getID() >= 0) {
								String name = Crops.instance.getCropList()[tec.getID()].name();

								if (hash.containsKey(name)) {
									hash.put(name, hash.get(name) + 1);
								} else {
									hash.put(name, 1);
								}

							}

							tec.setID((short) -1);
							HelperCrop.setUpgraded(tec, true);

							try {
								tec.getClass().getMethod("attemptCrossing").invoke(tec);
							} catch (Exception e) {
								e.printStackTrace();
							}

						}

						Set<Entry<String, Integer>> entrySet = hash.entrySet();
						Entry<String, Integer>[] array = entrySet.toArray(new Entry[entrySet.size()]);
						Arrays.sort(array, 0, array.length, new Comparator<Entry<String, Integer>>() {

							@Override
							public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)
							{
								if (o1.getValue() == o2.getValue()) return 0;
								if ((Integer) o1.getValue() > (Integer) o2.getValue()) return 1;
								return -1;
							}

						});

						HelperCrop.sendChatToPlayer(player, "-- AttempCrossing ---------");

						for (Entry<String, Integer> entry : array) {
							HelperCrop.sendChatToPlayer(player, "" + entry.getValue() + "  " + entry.getKey());
						}
					}

				}
			}
		}

		return false;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void getSubItems(Item p_150895_1_, CreativeTabs p_150895_2_, List<ItemStack> p_150895_3_)
	{
		int[] table = {
			1, 5, 10, 50, 100, 500, 1000, 5000, 10000, 50000,
		};

		for (int times : table) {

			ItemStack itemStack = new ItemStack(p_150895_1_, 1, getMetaId());
			{
				StackEntityDebuggerCropCrosser stackEntiry = new StackEntityDebuggerCropCrosser();
				stackEntiry.times = times;
				stackEntiry.writeToItemStack(itemStack);
			}
			p_150895_3_.add(itemStack);
		}

	}

	@Override
	public String getItemStackDisplayName(ItemStack par1ItemStack)
	{
		StackEntityDebuggerCropCrosser stackEntiry = new StackEntityDebuggerCropCrosser();
		stackEntiry.readFromItemStack(par1ItemStack);

		return super.getItemStackDisplayName(par1ItemStack) + " - T:" + stackEntiry.times;
	}

	@Override
	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List<String> par3List, boolean par4)
	{
		super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);

		StackEntityDebuggerCropCrosser stackEntiry = new StackEntityDebuggerCropCrosser();
		stackEntiry.readFromItemStack(par1ItemStack);

		par3List.add("Times: " + stackEntiry.times);
	}

	protected int getTimes(ItemStack itemStack)
	{
		StackEntityDebuggerCropCrosser stackEntiry = new StackEntityDebuggerCropCrosser();
		stackEntiry.readFromItemStack(itemStack);
		return stackEntiry.times;
	}

}
