package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;
import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropHarvesterSeed extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropHarvesterSeed(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (world == null) return false;
		if (world.isRemote) return false;

		{
			TileEntity te = world.getTileEntity(x, y, z);
			if (te != null) {

				if (te instanceof ICropTile) {
					ICropTile tec = (ICropTile) te;

					if (tec.getID() >= 0) {
						CropCard card = Crops.instance.getCropList()[tec.getID()];

						{
							ItemStack is = card.getSeeds(tec);

							HelperCrop.dropAsEntity(world, x, y, z, is);
						}

					}

				}
			}
		}

		return false;
	}

}
