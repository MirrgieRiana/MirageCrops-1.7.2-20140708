package mirrgmods.itemsdebuggercrop.core;

import ic2.api.crops.CropCard;
import ic2.api.crops.Crops;
import ic2.api.crops.ICropTile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import mirrgmods.itemsdebuggercrop.framework.HelperCrop;
import mirrgmods.itemsdebuggercrop.framework.ItemMeta;
import mirrgmods.itemsdebuggercrop.framework.MetaItem;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class MetaItemDebuggerCropCrosserDumper extends MetaItem<ItemMeta<? super MetaItemDebuggerCropPicker>>
{

	@SideOnly(Side.CLIENT)
	protected IIcon itemIcon;
	protected String iconString;

	public MetaItemDebuggerCropCrosserDumper(String plainName)
	{
		iconString = ModuleCore.instance.getMod().getModId() + ":" + ModuleCore.instance.getModuleName() + "/" + plainName;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister par1IconRegister)
	{
		itemIcon = par1IconRegister.registerIcon(iconString);
	}

	@Override
	public IIcon getIcon(ItemStack stack, int pass)
	{
		return itemIcon;
	}

	@Override
	public int getColorFromItemStack(ItemStack par1ItemStack, int par2)
	{
		return 0xff88ff;
	}

	@Override
	public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List<String> par3List, boolean par4)
	{
		super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);

		par3List.add("click crop tile!");
		par3List.add("see std out");
	}

	@Override
	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float x2, float y2, float z2)
	{
		if (!world.isRemote) return false;

		TileEntity te = world.getTileEntity(x, y, z);
		if (te == null) return false;
		if (!(te instanceof ICropTile)) return false;
		ICropTile tec = (ICropTile) te;

		ArrayList<CropCard> cropCards = new ArrayList<CropCard>();

		{
			CropCard[] cropList = Crops.instance.getCropList();

			for (int i = 0; i < cropList.length; i++) {
				if (cropList[i] != null) {
					cropCards.add(cropList[i]);
				}
			}

			Collections.sort(cropCards, new Comparator<CropCard>() {

				@Override
				public int compare(CropCard a, CropCard b)
				{
					if (a.tier() == b.tier()) return 0;
					return a.tier() > b.tier() ? 1 : -1;
				}

			});

		}

		{
			System.out.print("Name, Id, Tier, DiscoveredBy, ");

			for (int j = 0; j < cropCards.size(); j++) {
				System.out.print("\"" + cropCards.get(j).name() + "\"");
				System.out.print(", ");
			}

			System.out.println();
		}

		for (int i = 0; i < cropCards.size(); i++) {

			System.out.print("\"" + cropCards.get(i).name() + "\"");
			System.out.print(", ");

			System.out.print(cropCards.get(i).getId());
			System.out.print(", ");

			System.out.print(cropCards.get(i).tier());
			System.out.print(", ");

			System.out.print("\"" + cropCards.get(i).discoveredBy() + "\"");
			System.out.print(", ");

			for (int j = 0; j < cropCards.size(); j++) {

				System.out.print(HelperCrop.calculateRatioFor(tec, cropCards.get(i), cropCards.get(j)));
				System.out.print(", ");

			}

			System.out.println();
		}

		return true;
	}

}
